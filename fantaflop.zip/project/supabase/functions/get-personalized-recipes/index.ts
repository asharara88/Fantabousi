import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, ChevronUp, Shield, Brain, Target, User, Activity, TrendingUp, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from "../components/ui/Button";
import { Card } from '../components/ui/Card';

export default function HomePage() {
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [expandedStep, setExpandedStep] = useState<string | null>(null);

  const toggleCard = (cardId: string) => {
    setExpandedCard(expandedCard === cardId ? null : cardId);
  };

  const toggleStep = (stepId: string) => {
    setExpandedStep(expandedStep === stepId ? null : stepId);
  };

  const features = [
    {
      id: 'evidence-based',
      icon: <Shield className="w-5 h-5 text-primary-600 dark:text-primary-400" />,
      title: 'Evidence-Based',
      description: 'Backed by clinical research and reviewed by experts — no hype, just results.',
      details: {
        title: 'Scientific Foundation',
        content: [
          '🟢 Green Tier: Multiple high-quality clinical trials with strong consensus',
          '🟡 Yellow Tier: Some supporting studies with moderate evidence',
          '🟠 Orange Tier: Preliminary research or limited clinical data'
        ],
        footer: 'Every recommendation is categorized by research quality to ensure you get the most scientifically supported options.'
      }
    },
    {
      id: 'ai-powered',
      icon: <Brain className="w-5 h-5 text-primary-600 dark:text-primary-400" />,
      title: 'AI-Powered',
      description: 'Real-time insights trained on your data, goals, and habits — continuously optimized.',
      details: {
        title: 'Intelligent Optimization',
        content: [
          '🧠 Pattern Recognition: Identifies trends in your health data',
          '📈 Predictive Analytics: Anticipates your body\'s needs',
          '🔄 Adaptive Learning: Improves recommendations over time',
          '🎤 Voice Interaction: Natural conversation with your health coach'
        ],
        footer: 'Our AI continuously learns from your responses and outcomes to provide increasingly personalized guidance.'
      }
    },
    {
      id: 'hyper-personalized',
      icon: <Target className="w-5 h-5 text-primary-600 dark:text-primary-400" />,
      title: 'Hyper-Personalized',
      description: 'Tailored to your biomarkers, behavior, and lifestyle preferences. Precision, not guesswork.',
      details: {
        title: 'Custom Biology',
        content: [
          '🧬 Genetic Factors: Considers your unique genetic makeup',
          '🔬 Biomarker Analysis: Lab results and health metrics integration',
          '⚡ Lifestyle Adaptation: Fits recommendations to your daily routine',
          '🎯 Goal Alignment: Focuses on your specific health objectives'
        ],
        footer: 'No two people are alike. Your recommendations are as unique as your biology and lifestyle.'
      }
    }
  ];

  const steps = [
    {
      id: 'step1',
      title: 'Tell us about you',
      description: 'Answer a quick onboarding quiz about your goals, habits, and preferences.',
      gradient: 'from-primary-500 to-primary-600'
    },
    {
      id: 'step2', 
      title: 'Sync your data',
      description: 'Connect wearables and health apps to personalize your insights.',
      gradient: 'from-secondary-500 to-secondary-600'
    },
    {
      id: 'step3',
      title: 'Meet your coach', 
      description: 'Get AI-powered guidance and recommendations tailored to your data.',
      gradient: 'from-tertiary-500 to-tertiary-600'
    },
    {
      id: 'step4',
      title: 'Start your stack',
      description: 'Receive a personalized supplement plan backed by science and tracked in real time.',
      gradient: 'from-accent-500 to-accent-600'
    },
    {
      id: 'step5',
      title: 'Track and adjust',
      description: 'Let the system and your digital coach refine your plan as your data evolves.',
      gradient: 'from-primary-500 to-secondary-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-gray-50/30 to-white dark:from-gray-900 dark:via-gray-800/30 dark:to-gray-900 flex flex-col items-center justify-center px-6 py-16 text-center transition-all duration-500 relative overflow-hidden">
      {/* Enhanced Background Pattern */}
      <div className="absolute inset-0 opacity-20 dark:opacity-30">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-gradient-to-br from-primary-200/60 to-secondary-200/60 dark:from-primary-500/20 dark:to-secondary-500/20 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-gradient-to-tr from-tertiary-200/60 to-accent-200/60 dark:from-tertiary-500/20 dark:to-accent-500/20 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-gradient-to-r from-primary-100/60 to-tertiary-100/60 dark:from-primary-500/15 dark:to-tertiary-500/15 rounded-full blur-3xl"></div>
      </div>

      {/* Hero Section */}
      <motion.div
        className="max-w-2xl space-y-4 relative z-10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center justify-center mb-6">
          <Sparkles className="w-8 h-8 text-primary-500 mr-3 animate-pulse" />
          <span className="text-sm font-medium text-primary-600 dark:text-primary-400 uppercase tracking-wider">
            AI-Powered Wellness
          </span>
        </div>
        <h1 className="text-5xl font-extrabold leading-tight text-gray-900 dark:text-white tracking-tight mb-8">
          <div className="h-16 sm:h-20 lg:h-24 mx-auto mb-4 flex items-center justify-center">
            {/* Light theme logo */}
            <img 
              src="https://leznzqfezoofngumpiqf.supabase.co/storage/v1/object/sign/logos/logo-light.svg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82ZjcyOGVhMS1jMTdjLTQ2MTYtOWFlYS1mZmI3MmEyM2U5Y2EiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJsb2dvcy9sb2dvLWxpZ2h0LnN2ZyIsImlhdCI6MTc1Mjk5NjI3MCwiZXhwIjoxNzg0NTMyMjcwfQ.Pbk_iTzwBqeKhTo6txsMEFoPAUetGcp3wKCNcSD5BBU"
              alt="Biowell Logo" 
              className="h-full w-auto object-contain dark:hidden"
            />
            {/* Dark theme logo */}
            <img 
              src="https://leznzqfezoofngumpiqf.supabase.co/storage/v1/object/sign/logos/logo-light.svg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82ZjcyOGVhMS1jMTdjLTQ2MTYtOWFlYS1mZmI3MmEyM2U5Y2EiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJsb2dvcy9sb2dvLWxpZ2h0LnN2ZyIsImlhdCI6MTc1Mjk5NjIzMCwiZXhwIjoxNzg0NTMyMjMwfQ.subdnkOuE59mFqdkvkkNNwjbzVFzookdbmobn8BiqbE"
              alt="Biowell Logo" 
              className="h-full w-auto object-contain hidden dark:block"
            />
          </div>
        </h1>
        <h1 className="text-5xl font-extrabold leading-tight bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 dark:from-white dark:via-gray-100 dark:to-white bg-clip-text text-transparent">
          Feel Better. <span className="bg-gradient-to-r from-primary-600 via-secondary-600 to-tertiary-600 bg-clip-text text-transparent">Every Day.</span>
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
          Your Personalized Tool to Smarter Health and Performance
        </p>
      </motion.div>

      {/* CTA */}
      <div className="mt-8 space-y-3">
        <Button>
          Create My Plan
        </Button>
        <p className="text-sm text-gray-500">Built by experts. Backed by results.</p>
      </div>

      {/* Sign In */}
      <motion.div 
        className="mt-6 text-sm text-gray-500 dark:text-gray-400 relative z-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.4 }}
      >
        Already have an account?{' '}
        <Link to="/login" className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 underline underline-offset-4 hover:underline-offset-2 transition-all duration-300 font-medium">
          Log in
        </Link>
      </motion.div>

      {/* Feature Cards */}
      <motion.div 
        className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl w-full relative z-10"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.6 }}
      >
        {features.map((feature, index) => (
          <div key={feature.id} className="relative">
            <Card 
              variant="elevated"
              className="p-6 text-left cursor-pointer hover:shadow-premium-xl transition-all duration-500 transform hover:-translate-y-2 hover:scale-[1.02] bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border border-gray-200/50 dark:border-gray-700/50 group"
              onClick={() => toggleCard(feature.id)}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-primary-50 to-primary-100 dark:from-primary-900/30 dark:to-primary-800/30 group-hover:scale-110 transition-transform duration-300">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    {feature.title}
                  </h3>
                </div>
                <motion.div
                  animate={{ rotate: expandedCard === feature.id ? 180 : 0, scale: expandedCard === feature.id ? 1.1 : 1 }}
                  transition={{ duration: 0.3, type: "spring", stiffness: 200 }}
                >
                  {expandedCard === feature.id ? (
                    <ChevronUp className="w-5 h-5 text-primary-600 dark:text-primary-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-500 dark:text-gray-400 group-hover:text-primary-600 dark:group-hover:text-primary-400" />
                  )}
                </motion.div>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed mb-4">
                {feature.description}
              </p>
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                <span className="text-sm text-primary-600 dark:text-primary-400 font-medium group-hover:text-primary-700 dark:group-hover:text-primary-300 transition-colors duration-300">
                  {expandedCard === feature.id ? 'Click to collapse' : 'Learn how it works →'}
                </span>
              </div>
            </Card>

            <AnimatePresence>
              {expandedCard === feature.id && (
                <motion.div
                  initial={{ opacity: 0, y: -20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.95 }}
                  transition={{ duration: 0.4, ease: "easeOut", type: "spring", stiffness: 200 }}
                  className="absolute top-full left-0 right-0 z-20 mt-4"
                >
                  <Card variant="premium" className="p-6 shadow-premium-xl border border-primary-100 dark:border-primary-800 bg-white/95 dark:bg-gray-800/95 backdrop-blur-sm">
                    <h4 className="font-semibold text-gray-900 dark:text-white mb-4 text-lg">
                      {feature.details.title}
                    </h4>
                    <div className="space-y-3 text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                      {feature.details.content.map((item, idx) => (
                        <div key={idx} className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-700/50">
                          <span className="text-lg">{item.slice(0, 2)}</span>
                          <span className="font-medium">{item.slice(3)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                      <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed italic">
                        {feature.details.footer}
                      </p>
                    </div>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </motion.div>

      {/* How It Works Section */}
      <motion.div 
        className="mt-20 max-w-4xl w-full relative z-10"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 1 }}
      >
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">How It Works</h2>
          <p className="text-gray-600 dark:text-gray-400">Your journey to optimized health in 5 simple steps</p>
        </div>
        
        <div className="space-y-4">
          {steps.map((step, index) => (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 1.2 + index * 0.1 }}
              className="relative"
            >
              <Card
                variant="elevated"
                className="p-6 cursor-pointer hover:shadow-premium-xl transition-all duration-500 transform hover:-translate-y-1 hover:scale-[1.01] bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border border-gray-200/50 dark:border-gray-700/50 group"
                onClick={() => toggleStep(step.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${step.gradient} flex items-center justify-center text-white font-bold text-sm shadow-lg`}>
                      <span className="transform group-hover:scale-110 transition-transform duration-300">
                        {String(index + 1).padStart(2, '0')}
                      </span>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors duration-300">
                        {step.title}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        {expandedStep === step.id ? 'Click to collapse' : 'Click to learn more'}
                      </p>
                    </div>
                  </div>
                  <motion.div
                    animate={{ 
                      rotate: expandedStep === step.id ? 180 : 0,
                      scale: expandedStep === step.id ? 1.1 : 1
                    }}
                    transition={{ duration: 0.3, type: "spring", stiffness: 200 }}
                  >
                    {expandedStep === step.id ? (
                      <ChevronUp className="w-5 h-5 text-primary-600 dark:text-primary-400" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-gray-500 dark:text-gray-400 group-hover:text-primary-600 dark:group-hover:text-primary-400" />
                    )}
                  </motion.div>
                </div>

                <AnimatePresence>
                  {expandedStep === step.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0, y: -10 }}
                      animate={{ height: 'auto', opacity: 1, y: 0 }}
                      exit={{ height: 0, opacity: 0, y: -10 }}
                      transition={{ duration: 0.4, ease: "easeOut" }}
                      className="overflow-hidden"
                    >
                      <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                        <div className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800 rounded-xl p-4">
                          <p className="text-gray-700 dark:text-gray-300 leading-relaxed font-medium">
                            {step.description}
                          </p>
                        </div>
                        <div className="mt-4 flex items-center text-sm text-primary-600 dark:text-primary-400">
                          <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${step.gradient} mr-2`} />
                          <span className="font-medium">
                            Step {index + 1} of 5 in your wellness journey
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}