import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface OpenAIRequest {
  messages?: ChatMessage[];
  user_message?: string;
  user_id?: string;
  max_tokens?: number;
  temperature?: number;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Get OpenAI API key from environment
    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    if (!openaiKey) {
      throw new Error("OpenAI API key not configured");
    }

    // Get Supabase credentials
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    
    if (!supabaseUrl || !supabaseKey) {
      throw new Error("Supabase credentials not configured");
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    const { messages = [], user_message, user_id, max_tokens = 500, temperature = 0.7 }: OpenAIRequest = await req.json();

    // Get user context if user_id is provided
    let userContext = "";
    if (user_id) {
      try {
        // Get user profile
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user_id)
          .single();

        // Get recent health metrics
        const { data: metrics } = await supabase
          .from('health_metrics')
          .select('*')
          .eq('user_id', user_id)
          .order('timestamp', { ascending: false })
          .limit(10);

        // Get user supplements
        const { data: supplements } = await supabase
          .from('user_supplements')
          .select(`
            *,
            supplement:supplements(name, description, tier)
          `)
          .eq('user_id', user_id)
          .eq('subscription_active', true);

        // Build context string
        if (profile) {
          userContext = `User Context:
- Age: ${profile.age || 'Not specified'}
- Health Goals: ${profile.primary_health_goals?.join(', ') || 'Not specified'}
- Activity Level: ${profile.activity_level || 'Not specified'}
- Diet Preference: ${profile.diet_preference || 'Not specified'}`;

          if (supplements && supplements.length > 0) {
            userContext += `\n- Current Supplements: ${supplements.map(s => s.supplement?.name).join(', ')}`;
          }
        }
      } catch (error) {
        console.error('Error fetching user context:', error);
      }
    }

    // Prepare system message with health coaching context
    const systemMessage: ChatMessage = {
      role: 'system',
      content: `You are a knowledgeable AI health coach for Biowell, an evidence-based wellness platform. Your role is to provide personalized, science-backed health guidance.

Key Guidelines:
- Provide actionable, evidence-based health advice
- Always recommend consulting healthcare professionals for medical concerns
- Focus on nutrition, fitness, sleep, stress management, and supplement guidance
- Be supportive, encouraging, and personalized
- Use the user context when available to personalize responses
- Keep responses concise but comprehensive (2-3 paragraphs max)
- Include specific recommendations when appropriate

${userContext ? `\n${userContext}` : ''}

Remember: You are not a replacement for medical care, but a knowledgeable guide for general wellness optimization.`
    };

    // Prepare messages for OpenAI
    const openaiMessages: ChatMessage[] = [systemMessage];
    
    if (messages.length > 0) {
      openaiMessages.push(...messages);
    }
    
    if (user_message) {
      openaiMessages.push({ role: 'user', content: user_message });
    }

    // Call OpenAI API
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: openaiMessages,
        max_tokens,
        temperature,
        presence_penalty: 0.1,
        frequency_penalty: 0.1,
      }),
    });

    if (!openaiResponse.ok) {
      const errorData = await openaiResponse.json().catch(() => ({ error: openaiResponse.statusText }));
      throw new Error(`OpenAI API error: ${errorData.error?.message || openaiResponse.statusText}`);
    }

    const data = await openaiResponse.json();
    const response = data.choices?.[0]?.message?.content || "I'm sorry, I couldn't generate a response right now.";

    return new Response(
      JSON.stringify({ response }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error processing OpenAI request:", error);
    
    return new Response(
      JSON.stringify({ 
        error: error.message || "Failed to process request",
        type: error.name || "UnknownError"
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      }
    );
  }
});