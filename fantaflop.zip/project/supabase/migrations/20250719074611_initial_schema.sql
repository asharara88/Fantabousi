[paste the SQL above]
