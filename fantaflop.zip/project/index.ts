import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.SUPABASE_URL ?? process.env.VITE_SUPABASE_URL ?? '';
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.VITE_SUPABASE_ANON_KEY ?? '';
const OPENAI_KEY = process.env.OPENAI_API_KEY ?? '';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

export async function handler(req: Request): Promise<Response> {
  try {
    const { userId, userQuestion } = await req.json();

    const { data: metrics } = await supabase
      .from('metrics')
      .select('*')
      .eq('user_id', userId)
      .single();

    const prompt = `Given the following user metrics: ${JSON.stringify(metrics)}. ` +
      `Answer the user's question: ${userQuestion}`;

    const aiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
      }),
    });

    const aiData = await aiRes.json();
    const reply = aiData.choices?.[0]?.message?.content ?? '';

    return new Response(JSON.stringify({ reply }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
