# Install TypeScript as a dev dependency
npm install --save-dev typescript

# Commit and push
git add package.json package-lock.json
git commit -m "Add TypeScript dependency for Netlify build"
git push origin main