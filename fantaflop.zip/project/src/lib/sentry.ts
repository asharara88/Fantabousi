import * as Sentry from '@sentry/browser';
import { BrowserTracing } from '@sentry/tracing';

// Sentry configuration with error handling
export function initSentry() {
  try {
    // Check if Sentry DSN is available
    const sentryDsn = import.meta.env.VITE_SENTRY_DSN;
    
    if (!sentryDsn) {
      console.warn('Sentry DSN not configured, skipping initialization');
      return;
    }

    // Log DSN for debugging (first 20 chars only for security)
    console.log('Sentry DSN configured:', sentryDsn.substring(0, 20) + '...');

    Sentry.init({
      dsn: sentryDsn,
      environment: import.meta.env.MODE || 'development',
      debug: import.meta.env.DEV, // Enable debug in development
      tracesSampleRate: import.meta.env.PROD ? 0.1 : 1.0,
      
      integrations: [
        new BrowserTracing({
          // Reduce instrumentation in case of conflicts
          routingInstrumentation: Sentry.reactRouterV6Instrumentation(
            React.useEffect,
            useLocation,
            useNavigationType,
            createRoutesFromChildren,
            matchRoutes
          ),
        }),
      ],

      // Filter out known problematic errors
      beforeSend(event, hint) {
        // Skip instrumentation handler errors
        if (hint.originalException?.message?.includes('instrumentation handler')) {
          console.warn('Sentry: Filtered out instrumentation handler error');
          return null;
        }
        
        // Skip WebSocket errors in development
        if (import.meta.env.DEV && hint.originalException?.message?.includes('WebSocket')) {
          return null;
        }
        
        return event;
      },

      // Graceful error handling for transport issues
      transport: import.meta.env.PROD ? undefined : {
        send: async (event) => {
          try {
            return await Sentry.getDefaultTransport()(event);
          } catch (error) {
            console.warn('Sentry transport failed:', error);
            return Promise.resolve();
          }
        }
      }
    });

    console.log('Sentry initialized successfully');
  } catch (error) {
    console.warn('Failed to initialize Sentry:', error);
    // Don't throw - gracefully continue without Sentry
  }
}

// Wrapper for Sentry breadcrumbs with error handling
export function addSentryBreadcrumb(breadcrumb: Parameters<typeof Sentry.addBreadcrumb>[0]) {
  try {
    Sentry.addBreadcrumb(breadcrumb);
  } catch (error) {
    console.warn('Sentry breadcrumb failed:', error);
  }
}

// Wrapper for Sentry exceptions with error handling
export function captureSentryException(error: Error, context?: Record<string, any>) {
  try {
    if (context) {
      Sentry.withScope((scope) => {
        Object.keys(context).forEach(key => {
          scope.setContext(key, context[key]);
        });
        Sentry.captureException(error);
      });
    } else {
      Sentry.captureException(error);
    }
  } catch (sentryError) {
    console.warn('Sentry exception capture failed:', sentryError);
    // Still log the original error
    console.error('Original error:', error);
  }
}

// Safe Sentry user context setting
export function setSentryUser(user: { id: string; email?: string }) {
  try {
    Sentry.setUser({
      id: user.id,
      email: user.email
    });
  } catch (error) {
    console.warn('Failed to set Sentry user context:', error);
  }
}

// Development mode Sentry disable option
export function disableSentryInDev() {
  if (import.meta.env.DEV) {
    console.warn('Sentry disabled in development mode');
    // Override Sentry methods to no-op
    Object.assign(Sentry, {
      init: () => {},
      captureException: () => {},
      addBreadcrumb: () => {},
      setUser: () => {}
    });
  }
}