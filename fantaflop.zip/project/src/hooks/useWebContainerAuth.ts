import { useEffect } from 'react';
import { auth } from '@webcontainer/api';

// Track whether the WebContainer auth has already been initialized
let isInitialized = false;

/**
 * Initializes the StackBlitz WebContainer authentication.
 * Ensures the code only runs in the browser.
 */
export default function useWebContainerAuth(): void {
  useEffect(() => {
    if (typeof window === 'undefined') return;

    if (!isInitialized) {
      auth.init({
        clientId: import.meta.env.VITE_WEBCONTAINER_CLIENT_ID
      });
      isInitialized = true;
    }
  }, []);
}
