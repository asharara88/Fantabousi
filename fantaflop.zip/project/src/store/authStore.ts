import { create } from 'zustand';
import { supabase } from '@/lib/supabase';
import { setSentryUser, captureSentryException } from '@/lib/sentry';

interface User {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
}

interface AuthState {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, firstName: string, lastName: string) => Promise<void>;
  signOut: () => Promise<void>;
  initialize: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  loading: true,

  signIn: async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;

      if (data.user) {
        // Guard against multiple rapid sign-in attempts
        const currentState = get();
        if (currentState.loading) {
          set({
            user: {
              id: data.user.id,
              email: data.user.email || '',
              firstName: data.user.user_metadata?.first_name,
              lastName: data.user.user_metadata?.last_name
            },
            loading: false
          });
          
          // Set Sentry user context safely
          setSentryUser({
            id: data.user.id,
            email: data.user.email || undefined
          });
        }
      }
    } catch (error) {
      console.warn('Sign in error:', error);
      set({ loading: false });
      captureSentryException(error as Error, { context: 'auth_signin' });
      throw error;
    }
  },

  signUp: async (email: string, password: string, firstName: string, lastName: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            first_name: firstName,
            last_name: lastName
          }
        }
      });

      if (error) throw error;

      if (data.user) {
        // Guard against multiple rapid sign-up attempts
        const currentState = get();
        if (currentState.loading) {
          set({
            user: {
              id: data.user.id,
              email: data.user.email || '',
              firstName,
              lastName
            },
            loading: false
          });
        }
      }
    } catch (error) {
      console.warn('Sign up error:', error);
      set({ loading: false });
      captureSentryException(error as Error, { context: 'auth_signup' });
      throw error;
    }
  },

  signOut: async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.warn('Sign out error:', error);
        captureSentryException(error as Error, { context: 'auth_signout' });
        // Still clear user state even if signOut fails
      }
      
      // Clear Sentry user context
      setSentryUser({ id: '', email: undefined });
      set({ user: null, loading: false });
    } catch (error) {
      console.warn('Sign out error:', error);
      captureSentryException(error as Error, { context: 'auth_signout_catch' });
      // Graceful fallback - clear user state regardless
      set({ user: null, loading: false });
    }
  },

  initialize: async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user) {
        set({
          user: {
            id: session.user.id,
            email: session.user.email || '',
            firstName: session.user.user_metadata?.first_name,
            lastName: session.user.user_metadata?.last_name
          },
          loading: false
        });
        
        // Set Sentry user context safely
        setSentryUser({
          id: session.user.id,
          email: session.user.email || undefined
        });
      } else {
        set({ user: null, loading: false });
      }
    } catch (error) {
      console.warn('Error initializing auth:', error);
      captureSentryException(error as Error, { context: 'auth_initialize' });
      // Graceful fallback
      set({ user: null, loading: false });
    } finally {
      set({ loading: false });
    }
  }
}));