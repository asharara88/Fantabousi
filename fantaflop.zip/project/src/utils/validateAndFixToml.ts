import * as toml from 'toml';

export interface ValidationResult {
  originalWithComments: string;
  corrected: string;
}

/**
 * Validate and attempt to fix a TOML string.
 * Adds comments on lines with issues and returns
 * a corrected version with simple quoting fixes.
 */
export function validateAndFixToml(tomlContent: string): ValidationResult {
  const lines = tomlContent.trim().split(/\r?\n/);
  const annotated: string[] = [];
  const corrected: string[] = [];

  const assignment = /^([A-Za-z0-9_.-]+)\s*=\s*(.+)$/;

  for (const line of lines) {
    const trimmed = line.trim();
    const match = assignment.exec(trimmed);
    if (match && !trimmed.startsWith('#')) {
      const key = match[1];
      const value = match[2].trim();
      const hasQuotes = /^".*"$/.test(value) || /^'.*'$/.test(value);
      const isNumber = /^[+-]?\d+(?:\.\d+)?$/.test(value);
      const isBool = /^(true|false)$/.test(value);

      if (!hasQuotes && !isNumber && !isBool && value !== '' && !value.startsWith('[') && !value.startsWith('{')) {
        annotated.push(`${line}  # value should be quoted`);
        corrected.push(`${key} = "${value}"`);
        continue;
      }
    }
    annotated.push(line);
    corrected.push(line);
  }

  const correctedContent = corrected.join('\n');

  // Validate corrected content using toml.parse
  try {
    toml.parse(correctedContent);
  } catch (_e) {
    // If parsing fails, return the original content with comments
    return { originalWithComments: annotated.join('\n'), corrected: tomlContent.trim() };
  }

  return { originalWithComments: annotated.join('\n'), corrected: correctedContent };
}
