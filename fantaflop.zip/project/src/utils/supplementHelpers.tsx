import { Tier } from '../types/supplement';

export const TIER_COLORS: Record<Tier, string> = {
  green: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
  yellow: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
  orange: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300',
  red: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
};

export const TIER_LABELS: Record<Tier, string> = {
  green: 'Strong evidence – Supported by multiple high-quality human clinical trials and major scientific consensus.',
  yellow: 'Moderate/emerging evidence – Some supporting studies, but either limited in scale, mixed results, or moderate scientific consensus.',
  orange: 'Limited/preliminary evidence – Mostly early-stage or animal/lab-based research, few or low-quality human trials.',
  red: 'Insufficient evidence – Not recommended due to lack of evidence or potential safety concerns.'
};

export const getTierBadge = (tier?: Tier) => {
  if (!tier) return null;
  
  const colors = TIER_COLORS[tier as Tier] || TIER_COLORS.orange;
  
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${colors}`}>
      {tier.charAt(0).toUpperCase() + tier.slice(1)} Tier
    </span>
  );
};

export const formatPrice = (price?: number): string => {
  if (!price && price !== 0) return 'N/A';
  return `${price.toFixed(2)} AED`;
};

export const calculateDiscountedPrice = (price?: number, discountPercent?: number): number => {
  if (!price || !discountPercent) return price || 0;
  return price - (price * (discountPercent / 100));
};