export interface User {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  createdAt: string;
}

export interface HealthMetric {
  id: string;
  userId: string;
  type: 'sleep' | 'fitness' | 'nutrition' | 'supplements';
  value: number;
  unit: string;
  timestamp: string;
}

export interface Supplement {
  id: string;
  name: string;
  brand: string;
  description: string;
  price: number;
  category: string;
  tier: 'green' | 'yellow' | 'orange';
  rating: number;
  imageUrl: string;
}

export interface Workout {
  id: string;
  userId: string;
  name: string;
  type: string;
  duration: number;
  caloriesBurned: number;
  exercises: Exercise[];
  completedAt: string;
}

export interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: number;
  weight?: number;
  duration?: number;
}

export interface Meal {
  id: string;
  userId: string;
  name: string;
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}