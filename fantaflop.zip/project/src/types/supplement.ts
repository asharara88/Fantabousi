// Supplement types
export type Tier = 'green' | 'yellow' | 'orange' | 'red';

export interface Supplement {
  id: string;
  name: string;
  brand?: string;
  description?: string;
  detailed_description?: string;
  price?: number;
  price_aed?: number;
  image_url?: string;
  tier?: Tier;
  benefits?: string[];
  dosage?: string;
  form_type?: string;
  form_image_url?: string;
  goal?: string;
  mechanism?: string;
  evidence_summary?: string;
  source_link?: string;
  nutritional_info?: string;
  stock_quantity?: number;
  is_available?: boolean;
  is_featured?: boolean;
  is_bestseller?: boolean;
  subscription_discount_percent?: number;
  use_case?: string;
  evidence_rating?: number;
  category?: string;
  created_at?: string;
  updated_at?: string;
}

export interface StackComponent {
  id?: string;
  name: string;
  dosage: string;
  timing: string;
  price: number;
  notes?: string;
}

export interface SupplementStack {
  id: string;
  user_id?: string;
  category: string;
  name: string;
  description?: string;
  total_price: number;
  components: StackComponent[];
  is_active?: boolean;
  goals?: string[];
  created_at?: string;
  updated_at?: string;
}

export interface CartItem {
  id: string;
  user_id: string;
  supplement_id: string;
  supplement: Supplement;
  quantity: number;
  created_at?: string;
  updated_at?: string;
}

export interface RecommendationResponse {
  supplements: Supplement[];
  stacks: SupplementStack[];
  personalized_message: string;
}