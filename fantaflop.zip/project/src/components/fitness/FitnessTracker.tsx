import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/Card';
import { Button } from '../ui/Button';
import { Activity, Calendar, Zap, Target, Plus, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { workoutsApi } from '../../api/supabaseApi';

interface WorkoutSession {
  id: string;
  user_id: string;
  workout_type: string;
  duration: number;
  calories_burned: number;
  timestamp: string;
  notes?: string;
}

interface FitnessSummary {
  totalWorkouts: number;
  totalCaloriesBurned: number;
  totalActiveMinutes: number;
  dailyMetrics: Array<{
    date: string;
    workouts: number;
    caloriesBurned: number;
    activeMinutes: number;
  }>;
}

const FitnessTracker: React.FC = () => {
  const [fitnessSummary, setFitnessSummary] = useState<FitnessSummary | null>(null);
  const [recentWorkouts, setRecentWorkouts] = useState<WorkoutSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddWorkout, setShowAddWorkout] = useState(false);
  const [newWorkout, setNewWorkout] = useState({
    workout_type: '',
    duration: '',
    calories_burned: '',
    notes: ''
  });

  useEffect(() => {
    loadFitnessData();
  }, []);

  const loadFitnessData = async () => {
    try {
      setIsLoading(true);
      const [summary, workouts] = await Promise.all([
        workoutsApi.getFitnessSummary(7),
        workoutsApi.getWorkoutHistory(5)
      ]);
      
      setFitnessSummary(summary);
      setRecentWorkouts(workouts);
    } catch (error) {
      console.error('Error loading fitness data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddWorkout = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const workoutData = {
        workout_type: newWorkout.workout_type,
        duration: parseInt(newWorkout.duration),
        calories_burned: parseInt(newWorkout.calories_burned),
        notes: newWorkout.notes,
        timestamp: new Date().toISOString()
      };

      const savedWorkout = await workoutsApi.logWorkout(workoutData);
      
      if (savedWorkout) {
        setRecentWorkouts(prev => [savedWorkout, ...prev.slice(0, 4)]);
        setNewWorkout({ workout_type: '', duration: '', calories_burned: '', notes: '' });
        setShowAddWorkout(false);
        // Refresh summary
        const summary = await workoutsApi.getFitnessSummary(7);
        setFitnessSummary(summary);
      }
    } catch (error) {
      console.error('Error adding workout:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          Fitness Tracker
        </h2>
        <Button onClick={() => setShowAddWorkout(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Log Workout
        </Button>
      </div>

      {/* Summary Cards */}
      {fitnessSummary && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Workouts</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{fitnessSummary.totalWorkouts}</div>
                <p className="text-xs text-muted-foreground">Last 7 days</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Calories Burned</CardTitle>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{fitnessSummary.totalCaloriesBurned}</div>
                <p className="text-xs text-muted-foreground">Last 7 days</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Minutes</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{fitnessSummary.totalActiveMinutes}</div>
                <p className="text-xs text-muted-foreground">Last 7 days</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      )}

      {/* Recent Workouts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            Recent Workouts
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentWorkouts.length > 0 ? (
            <div className="space-y-4">
              {recentWorkouts.map((workout) => (
                <motion.div
                  key={workout.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                >
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-primary-100 dark:bg-primary-900 rounded-lg">
                      <Activity className="w-5 h-5 text-primary-600 dark:text-primary-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white">
                        {workout.workout_type}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {workout.duration} min • {workout.calories_burned} cal
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {new Date(workout.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Activity className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No workouts logged yet</p>
              <Button 
                className="mt-4" 
                onClick={() => setShowAddWorkout(true)}
              >
                Log Your First Workout
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Workout Modal */}
      {showAddWorkout && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Log New Workout</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddWorkout} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Workout Type</label>
                  <input
                    type="text"
                    value={newWorkout.workout_type}
                    onChange={(e) => setNewWorkout(prev => ({ ...prev, workout_type: e.target.value }))}
                    placeholder="e.g., Strength Training, Cardio, Yoga"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Duration (minutes)</label>
                  <input
                    type="number"
                    value={newWorkout.duration}
                    onChange={(e) => setNewWorkout(prev => ({ ...prev, duration: e.target.value }))}
                    placeholder="30"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Calories Burned</label>
                  <input
                    type="number"
                    value={newWorkout.calories_burned}
                    onChange={(e) => setNewWorkout(prev => ({ ...prev, calories_burned: e.target.value }))}
                    placeholder="250"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Notes (optional)</label>
                  <textarea
                    value={newWorkout.notes}
                    onChange={(e) => setNewWorkout(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="How did it feel? Any observations..."
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    rows={3}
                  />
                </div>

                <div className="flex space-x-3">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddWorkout(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="flex-1">
                    Log Workout
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default FitnessTracker;