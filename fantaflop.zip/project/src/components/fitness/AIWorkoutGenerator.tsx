import React, { useState } from 'react';
import { Dumbbell, Clock, Target, Zap, Play, RefreshCw } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { aiWorkoutPlannerApi, WorkoutPlan, Exercise } from '../../api/aiWorkoutPlannerApi';

interface AIWorkoutGeneratorProps {
  onWorkoutGenerated?: (workout: WorkoutPlan) => void;
}

const AIWorkoutGenerator: React.FC<AIWorkoutGeneratorProps> = ({ onWorkoutGenerated }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedWorkout, setGeneratedWorkout] = useState<WorkoutPlan | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [preferences, setPreferences] = useState({
    goal: 'muscle_building',
    experience: 'intermediate',
    duration: 45,
    equipment: [] as string[],
    targetMuscles: [] as string[]
  });

  const goals = [
    { value: 'muscle_building', label: 'Muscle Building' },
    { value: 'weight_loss', label: 'Weight Loss' },
    { value: 'strength', label: 'Strength Training' },
    { value: 'endurance', label: 'Endurance' },
    { value: 'flexibility', label: 'Flexibility' }
  ];

  const experienceLevels = [
    { value: 'beginner', label: 'Beginner' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' }
  ];

  const equipmentOptions = [
    'dumbbells', 'barbell', 'resistance_bands', 'kettlebells', 
    'pull_up_bar', 'yoga_mat', 'bodyweight', 'cables'
  ];

  const muscleGroups = [
    'chest', 'back', 'shoulders', 'arms', 'core', 'legs', 'glutes'
  ];

  const handleGenerateWorkout = async () => {
    setIsGenerating(true);
    setError(null);
    
    try {
      // Add timeout to prevent hanging requests
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Request timeout')), 8000)
      );
      
      const workoutPromise = aiWorkoutPlannerApi.generateWorkoutPlan(preferences);
      
      const workout = await Promise.race([workoutPromise, timeoutPromise]) as any;
      
      if (workout) {
        setGeneratedWorkout(workout);
        onWorkoutGenerated?.(workout);
      } else {
        setError('No workout plan was generated. Please try adjusting your preferences.');
      }
    } catch (error) {
      console.error('Error generating workout:', error);
      
      if (error.message?.includes('timeout')) {
        setError('Request timed out. The workout generator may be temporarily unavailable.');
      } else {
        setError('Failed to generate workout. The service may be temporarily unavailable.');
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleEquipment = (equipment: string) => {
    setPreferences(prev => ({
      ...prev,
      equipment: prev.equipment.includes(equipment)
        ? prev.equipment.filter(e => e !== equipment)
        : [...prev.equipment, equipment]
    }));
  };

  const toggleMuscleGroup = (muscle: string) => {
    setPreferences(prev => ({
      ...prev,
      targetMuscles: prev.targetMuscles.includes(muscle)
        ? prev.targetMuscles.filter(m => m !== muscle)
        : [...prev.targetMuscles, muscle]
    }));
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex items-center mb-6">
          <Dumbbell className="w-6 h-6 text-primary-600 dark:text-primary-400 mr-3" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            AI Workout Generator
          </h2>
        </div>

        {/* Preferences Form */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Goal Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Fitness Goal
            </label>
            <select
              value={preferences.goal}
              onChange={(e) => setPreferences(prev => ({ ...prev, goal: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              {goals.map(goal => (
                <option key={goal.value} value={goal.value}>
                  {goal.label}
                </option>
              ))}
            </select>
          </div>

          {/* Experience Level */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Experience Level
            </label>
            <select
              value={preferences.experience}
              onChange={(e) => setPreferences(prev => ({ ...prev, experience: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              {experienceLevels.map(level => (
                <option key={level.value} value={level.value}>
                  {level.label}
                </option>
              ))}
            </select>
          </div>

          {/* Duration */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Duration (minutes)
            </label>
            <input
              type="number"
              min="15"
              max="120"
              step="15"
              value={preferences.duration}
              onChange={(e) => setPreferences(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
        </div>

        {/* Equipment Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Available Equipment
          </label>
          <div className="flex flex-wrap gap-2">
            {equipmentOptions.map(equipment => (
              <button
                key={equipment}
                onClick={() => toggleEquipment(equipment)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  preferences.equipment.includes(equipment)
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {equipment.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Target Muscles */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Target Muscle Groups (optional)
          </label>
          <div className="flex flex-wrap gap-2">
            {muscleGroups.map(muscle => (
              <button
                key={muscle}
                onClick={() => toggleMuscleGroup(muscle)}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  preferences.targetMuscles.includes(muscle)
                    ? 'bg-secondary-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {muscle}
              </button>
            ))}
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-300 text-sm">
            {error}
          </div>
        )}

        {/* Generate Button */}
        <Button
          onClick={handleGenerateWorkout}
          disabled={isGenerating}
          className="w-full mb-6"
          aria-label="Generate personalized AI workout plan"
        >
          {isGenerating ? (
            <>
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              Creating your workout plan...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 mr-2" />
              Create my workout plan
            </>
          )}
        </Button>
      </Card>

      {/* Generated Workout Display */}
      {generatedWorkout && (
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">
              {generatedWorkout.name}
            </h3>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
              <Clock className="w-4 h-4 mr-1" />
              {generatedWorkout.duration} min
            </div>
          </div>

          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {generatedWorkout.description}
          </p>

          <div className="flex items-center space-x-4 mb-6">
            <div className="flex items-center">
              <Target className="w-4 h-4 text-primary-600 dark:text-primary-400 mr-1" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                Difficulty: {generatedWorkout.difficulty}
              </span>
            </div>
            <div className="flex items-center">
              <Dumbbell className="w-4 h-4 text-secondary-600 dark:text-secondary-400 mr-1" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {generatedWorkout.exercises.length} exercises
              </span>
            </div>
          </div>

          {/* Exercise List */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-gray-900 dark:text-white">
              Exercises
            </h4>
            {generatedWorkout.exercises.map((exercise, index) => (
              <div
                key={exercise.id}
                className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h5 className="font-medium text-gray-900 dark:text-white">
                      {index + 1}. {exercise.name}
                    </h5>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      {exercise.description}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {exercise.sets} sets × {exercise.reps}
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mb-2">
                  {exercise.muscleGroups.map(muscle => (
                    <span
                      key={muscle}
                      className="px-2 py-1 bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-200 text-xs rounded-full"
                    >
                      {muscle}
                    </span>
                  ))}
                </div>

                {exercise.instructions && exercise.instructions.length > 0 && (
                  <div className="mt-3">
                    <h6 className="text-sm font-medium text-gray-900 dark:text-white mb-1">
                      Instructions:
                    </h6>
                    <ol className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      {exercise.instructions.map((instruction, idx) => (
                        <li key={idx} className="flex">
                          <span className="mr-2">{idx + 1}.</span>
                          <span>{instruction}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-6">
            <Button variant="outline" className="flex-1">
              <Play className="w-4 h-4 mr-2" />
              Start this workout
            </Button>
            <Button variant="outline" onClick={handleGenerateWorkout}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Create different plan
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
};

export default AIWorkoutGenerator;