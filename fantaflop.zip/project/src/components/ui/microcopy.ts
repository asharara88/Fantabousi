// Centralized microcopy for consistent, user-friendly interface text
// Following UX best practices for clarity, helpfulness, and task completion

export const microcopy = {
  // Authentication & Onboarding
  auth: {
    buttons: {
      signIn: "Sign in to your account",
      signUp: "Create your free account", 
      getStarted: "Start your wellness journey",
      forgotPassword: "Reset your password",
      resendEmail: "Resend verification email"
    },
    placeholders: {
      email: "Enter your email address",
      password: "Enter your password", 
      confirmPassword: "Confirm your password",
      firstName: "Your first name",
      lastName: "Your last name"
    },
    hints: {
      email: "We'll use this to send you health insights and account updates",
      password: "Must be at least 8 characters with one number",
      confirmPassword: "Re-enter your password to confirm",
      existingAccount: "Already optimizing your health with us?"
    },
    errors: {
      invalidEmail: "Please enter a valid email address (like john@example.com)",
      passwordTooShort: "Password needs at least 8 characters to keep your account secure",
      passwordMismatch: "Passwords don't match - please try again", 
      accountExists: "An account with this email already exists. Try signing in instead.",
      invalidCredentials: "Email or password incorrect. Double-check and try again.",
      networkError: "Connection issue. Check your internet and try again.",
      genericError: "Something went wrong. Please try again in a moment."
    },
    success: {
      accountCreated: "Welcome to Biowell! Check your email to verify your account.",
      signInSuccess: "Welcome back! Loading your health dashboard...",
      passwordReset: "Password reset link sent to your email"
    },
    loading: {
      signingIn: "Signing you in...",
      creatingAccount: "Creating your account...",
      resettingPassword: "Sending reset instructions..."
    }
  },

  // Navigation & Orientation
  navigation: {
    labels: {
      dashboard: "Health Dashboard",
      coach: "AI Health Coach", 
      nutrition: "Nutrition & Meals",
      fitness: "Fitness & Exercise",
      sleep: "Sleep & Recovery",
      supplements: "Supplements & Stacks",
      metabolism: "Metabolism & CGM",
      bioclock: "Circadian Health"
    },
    descriptions: {
      dashboard: "Your complete health overview and daily metrics",
      coach: "Get personalized AI guidance for your wellness goals",
      nutrition: "Track meals, analyze nutrition, and discover recipes",
      fitness: "Log workouts, track progress, and visualize muscle recovery", 
      sleep: "Optimize sleep quality and recovery patterns",
      supplements: "Evidence-based supplements tailored to your needs",
      metabolism: "Monitor glucose levels and metabolic health",
      bioclock: "Align your lifestyle with your natural circadian rhythm"
    },
    breadcrumbs: {
      home: "Dashboard",
      current: "You are here"
    }
  },

  // Forms & Input
  forms: {
    buttons: {
      save: "Save changes",
      saveAndContinue: "Save & continue",
      cancel: "Cancel", 
      delete: "Delete",
      edit: "Edit",
      add: "Add",
      remove: "Remove",
      upload: "Choose file",
      search: "Search",
      filter: "Filter results",
      reset: "Reset to defaults",
      submit: "Submit"
    },
    placeholders: {
      search: "Search supplements, foods, or exercises...",
      notes: "Add any notes or observations...",
      goals: "Describe your health goals...",
      feedback: "How can we improve your experience?",
      dosage: "e.g., 500mg daily",
      timing: "e.g., with breakfast",
      weight: "Enter your current weight",
      height: "Enter your height"
    },
    hints: {
      required: "Required field",
      optional: "Optional",
      characterLimit: "characters remaining",
      fileFormat: "Accepted formats: JPG, PNG (max 5MB)",
      privacy: "This information is private and secure",
      aiProcessing: "Our AI will analyze this to personalize your recommendations"
    },
    validation: {
      required: "This field is required to continue",
      invalidFormat: "Please check the format and try again",
      tooShort: "Please provide more detail",
      tooLong: "Please keep it under {max} characters",
      invalidNumber: "Please enter a valid number",
      outOfRange: "Please enter a value between {min} and {max}"
    }
  },

  // Loading States
  loading: {
    general: "Loading...",
    dashboard: "Loading your health dashboard...",
    recommendations: "Analyzing your profile for personalized recommendations...",
    aiResponse: "AI Coach is thinking...",
    voiceGeneration: "Generating voice response...",
    foodAnalysis: "Analyzing your meal's nutrition...",
    workoutPlan: "Creating your personalized workout...",
    supplements: "Loading evidence-based supplements...",
    saving: "Saving your changes...",
    uploading: "Uploading your file...",
    processing: "Processing your request..."
  },

  // Empty States
  empty: {
    dashboard: {
      title: "Welcome to your health journey!",
      description: "Complete your profile to see personalized insights and recommendations here.",
      action: "Complete your profile"
    },
    supplements: {
      title: "No supplements in your stack yet",
      description: "Build your first evidence-based supplement stack tailored to your health goals.",
      action: "Browse supplements"
    },
    meals: {
      title: "No meals logged today",
      description: "Start tracking your nutrition to get personalized insights and recommendations.",
      action: "Log your first meal"
    },
    workouts: {
      title: "Ready to start exercising?",
      description: "Log your first workout to track progress and optimize your fitness routine.",
      action: "Log a workout"
    },
    chatHistory: {
      title: "Start a conversation with your AI coach",
      description: "Ask about nutrition, fitness, supplements, or any health questions you have.",
      action: "Ask your first question"
    },
    search: {
      title: "No results found",
      description: "Try different keywords or check your spelling. We're here to help you find what you need.",
      action: "Clear search and try again"
    }
  },

  // Success Messages
  success: {
    saved: "Changes saved successfully",
    added: "Successfully added to your stack",
    removed: "Removed from your collection", 
    updated: "Information updated",
    shared: "Successfully shared",
    uploaded: "File uploaded successfully",
    subscribed: "You're all set! Welcome to Biowell Pro.",
    goalCompleted: "Congratulations! You've reached your goal.",
    streakMaintained: "Great job maintaining your wellness streak!"
  },

  // Error Messages
  errors: {
    network: "Connection issue. Please check your internet and try again.",
    server: "Our servers are taking a short break. Please try again in a moment.",
    notFound: "We couldn't find what you're looking for. It might have been moved or deleted.",
    unauthorized: "Please sign in again to continue accessing your health data.",
    forbidden: "You don't have permission to access this feature.",
    timeout: "This is taking longer than expected. Please try again.",
    fileUpload: "File upload failed. Please check the file format and size, then try again.",
    aiError: "AI Coach is temporarily unavailable. Try again in a moment or contact support.",
    paymentError: "Payment couldn't be processed. Please check your card details and try again.",
    genericError: "Something unexpected happened. We're looking into it - please try again."
  },

  // Call-to-Action (CTA) Improvements
  cta: {
    primary: {
      getStarted: "Start optimizing your health",
      signUp: "Join Biowell today", 
      upgrade: "Unlock personalized insights",
      subscribe: "Get your monthly supplements",
      analyze: "Analyze my nutrition",
      generatePlan: "Create my workout plan",
      bookConsultation: "Talk to a health expert"
    },
    secondary: {
      learnMore: "See how it works",
      viewDetails: "View full details",
      readMore: "Read the complete guide",
      watchDemo: "Watch 2-min demo",
      downloadReport: "Download your report",
      shareResults: "Share with your doctor"
    }
  },

  // Tooltips & Help Text
  help: {
    bwScore: "Your BioWell Score combines multiple health metrics into one easy-to-understand number",
    supplementTiers: "Green = Strong evidence, Yellow = Moderate evidence, Orange = Limited evidence",
    macroRatios: "Optimal protein: 25-35%, carbs: 30-50%, fats: 20-35%",
    sleepScore: "Based on duration, quality, and consistency of your sleep patterns",
    cgmReadings: "Normal range: 70-140 mg/dL. Target: 70% time in range",
    voiceSettings: "Adjust voice speed and clarity for your AI coach responses"
  },

  // Progress & Achievements
  progress: {
    completing: "Completing your setup...",
    analyzing: "Analyzing your health data...",
    personalizing: "Creating your personalized plan...",
    almostDone: "Almost finished!",
    wellDone: "Well done!",
    keepGoing: "You're making great progress!",
    milestone: "Milestone achieved!"
  },

  // Time-sensitive & Contextual
  contextual: {
    goodMorning: "Good morning! Ready to optimize your day?",
    welcomeBack: "Welcome back! Here's what's new with your health.",
    firstTime: "First time here? Let's get you set up.",
    weeklyReview: "Here's your week in review",
    monthlyInsights: "Your monthly health insights are ready",
    reminderGentle: "Friendly reminder: Don't forget to log your supplements",
    encouragement: "Small steps lead to big changes. Keep it up!"
  },

  // Mobile-specific
  mobile: {
    tapToExpand: "Tap to see more details",
    swipeForMore: "Swipe for more options", 
    pullToRefresh: "Pull down to refresh",
    tapAndHold: "Tap and hold for quick actions",
    scrollForMore: "Scroll down for more content"
  }
};

// Utility functions for dynamic microcopy
export const getMicrocopy = {
  // Personalized greeting based on time of day
  greeting: (): string => {
    const hour = new Date().getHours();
    if (hour < 12) return microcopy.contextual.goodMorning;
    if (hour < 18) return "Good afternoon! How's your wellness journey going?";
    return "Good evening! Time to review your day's progress.";
  },

  // Dynamic error messages with helpful context
  errorWithAction: (error: string, action?: string): string => {
    const baseError = microcopy.errors[error] || microcopy.errors.genericError;
    return action ? `${baseError} ${action}` : baseError;
  },

  // Progress messages based on completion percentage
  progressMessage: (percentage: number): string => {
    if (percentage < 25) return "Just getting started...";
    if (percentage < 50) return microcopy.progress.keepGoing;
    if (percentage < 75) return "You're halfway there!";
    if (percentage < 100) return microcopy.progress.almostDone;
    return microcopy.progress.wellDone;
  },

  // Character count helpers
  characterCount: (current: number, max: number): string => {
    const remaining = max - current;
    if (remaining < 0) return `${Math.abs(remaining)} characters over limit`;
    if (remaining < 10) return `${remaining} characters left`;
    return `${remaining} ${microcopy.forms.hints.characterLimit}`;
  }
};