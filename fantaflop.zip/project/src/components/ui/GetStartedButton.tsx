import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from './Button';
import { motion } from 'framer-motion';

interface GetStartedButtonProps {
  size?: 'default' | 'lg' | 'xl';
  variant?: 'primary' | 'gradient';
  className?: string;
  showIcon?: boolean;
  animated?: boolean;
}

export const GetStartedButton: React.FC<GetStartedButtonProps> = ({
  size = 'lg',
  variant = 'gradient',
  className = '',
  showIcon = true,
  animated = true
}) => {
  const sizeClasses = {
    default: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg',
    xl: 'px-12 py-6 text-xl'
  };

  const ButtonComponent = animated ? motion.div : 'div';
  const buttonProps = animated ? {
    whileHover: { scale: 1.05 },
    whileTap: { scale: 0.95 },
    transition: { duration: 0.2 }
  } : {};

  return (
    <ButtonComponent {...buttonProps}>
      <Button
        as={Link}
        to="/get-started"
        className={`
          ${variant === 'gradient' 
            ? 'bg-gradient-to-r from-primary-600 via-secondary-500 to-tertiary-600 hover:from-primary-700 hover:via-secondary-600 hover:to-tertiary-700 text-white shadow-lg hover:shadow-xl' 
            : 'bg-primary-600 hover:bg-primary-700 text-white'
          }
          ${sizeClasses[size]}
          font-semibold rounded-xl
          transform transition-all duration-300
          flex items-center space-x-2
          border-0 focus:ring-4 focus:ring-primary/30
          ${className}
        `}
      >
        {showIcon && <Sparkles className="w-5 h-5" />}
        <span>Get Started</span>
        {showIcon && <ArrowRight className="w-5 h-5" />}
      </Button>
    </ButtonComponent>
  );
};

export default GetStartedButton;