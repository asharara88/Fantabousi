import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { X, ChevronDown, ChevronRight } from 'lucide-react';
import { cn } from '../../utils/cn';
import Navigation from '../layout/Navigation';

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  isLoggedIn?: boolean;
  onSignOut?: () => void;
}

// Organized navigation structure for mobile
const mobileNavSections = [
  {
    title: 'Main',
    items: [
      { name: 'Dashboard', href: '/dashboard', icon: Home },
      { name: 'Coach', href: '/mycoach', icon: MessageCircle, badge: 'AI' }
    ]
  },
  {
    title: 'Health Tracking',
    items: [
      { name: 'Nutrition', href: '/nutrition', icon: Utensils },
      { name: 'Fitness', href: '/fitness', icon: Activity },
      { name: 'Sleep', href: '/sleep', icon: Moon },
      { name: 'Metabolism', href: '/metabolism', icon: Zap },
      { name: 'MyBio', href: '/mybio', icon: BarChart3 }
    ]
  },
  {
    title: 'Supplements',
    items: [
      { name: 'Store', href: '/supplements', icon: Pill },
      { name: 'My Stacks', href: '/mystacks', icon: Layers },
      { name: 'Recommendations', href: '/supplements/recommendations', icon: Target },
      { name: 'Cart', href: '/cart', icon: ShoppingCart }
    ]
  }
];

const MobileNav: React.FC<MobileNavProps> = ({ 
  isOpen, 
  onClose, 
  isLoggedIn = false,
  onSignOut
}) => {
  const location = useLocation();

  // Close mobile nav when route changes
  React.useEffect(() => {
    if (isOpen) {
      onClose();
    }
  }, [location.pathname]);

  return (
    <div 
      className={cn(
        "fixed inset-0 z-50 bg-black bg-opacity-50 transition-opacity duration-300",
        isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
      )}
      onClick={onClose}
    >
      <div 
        className={cn(
          "fixed top-0 right-0 h-full w-4/5 max-w-sm bg-white dark:bg-gray-900 shadow-xl transform transition-transform duration-300 ease-in-out overflow-y-auto",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-6 border-b border-gray-200 dark:border-gray-800 bg-gradient-to-r from-primary-50 to-secondary-50 dark:from-primary-900/20 dark:to-secondary-900/20">
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Navigation</h2>
            <p className="text-sm text-gray-600 dark:text-gray-400">Biowell Health Platform</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 touch-target min-h-[44px] min-w-[44px]"
            aria-label="Close menu"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-4 space-y-6">
          {mobileNavSections.map((section) => (
            <div key={section.title}>
              <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3 px-2">
                {section.title}
              </h3>
              <div className="space-y-1">
                {section.items.map((item) => (
                  <Link
                    key={item.href}
                    to={item.href}
                    onClick={onClose}
                    className={cn(
                      "flex items-center px-3 py-3 rounded-xl text-base font-medium transition-all duration-200 touch-target min-h-[44px]",
                      location.pathname === item.href
                        ? "bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300"
                        : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                    )}
                  >
                    <item.icon className="w-5 h-5 mr-3 flex-shrink-0" />
                    <span className="flex-1">{item.name}</span>
                    {item.badge && (
                      <span className="ml-2 px-2 py-1 text-xs bg-accent text-white rounded-full">
                        {item.badge}
                      </span>
                    )}
                    <ChevronRight className="w-4 h-4 ml-2 text-gray-400" />
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <div className="p-4 border-t border-gray-200 dark:border-gray-800">
          <div className="space-y-3">
            {isLoggedIn ? (
              <>
                <div className="flex items-center px-3 py-2 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <User className="w-4 h-4 mr-3 text-gray-500 dark:text-gray-400" />
                  <span className="text-sm text-gray-700 dark:text-gray-300 truncate">
                    {/* Add user email/name here */}
                    Signed in
                  </span>
                </div>
                <button 
                  onClick={() => {
                    onSignOut?.();
                    onClose();
                  }}
                  className="flex items-center justify-center w-full px-4 py-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg font-medium text-red-700 dark:text-red-300 hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors touch-target min-h-[44px]"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="flex items-center justify-center w-full px-4 py-3 bg-primary hover:bg-primary-dark text-white rounded-lg font-medium transition-colors touch-target min-h-[44px]"
                  onClick={onClose}
                >
                  Sign In
                </Link>
                <Link 
                  to="/signup" 
                  className="flex items-center justify-center w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-lg font-medium text-gray-900 dark:text-white hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors touch-target min-h-[44px]"
                  onClick={onClose}
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileNav;