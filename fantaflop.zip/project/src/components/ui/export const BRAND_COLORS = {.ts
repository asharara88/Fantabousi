export const BRAND_COLORS = {
  gradient: {
    start: '#0575E6',
    end: '#021B79',
    class: 'from-[#0575E6] to-[#021B79]',
  },
  accent: {
    DEFAULT: '#22c55e',
    focus: 'focus:ring-green-500',
    hover: 'hover:ring-green-500/30',
  },
  text: {
    light: '#1f2937',
    dark: '#f9fafb',
  },
} as const;

export const BRAND_CLASSES = {
  button: {
    primary: 'bg-gradient-to-br from-[#0575E6] to-[#021B79] text-white hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2',
    secondary: 'bg-gray-200 text-gray-900 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-100 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2',
    ghost: 'bg-transparent hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2',
    danger: 'bg-red-600 text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2',
  },
  card: {
    hover: 'hover:ring-2 hover:ring-green-500/30 hover:shadow-green-500/10',
    base: 'transition-all duration-300',
  },
  focus: 'focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2',
  link: {
    primary: 'text-[#0575E6] hover:text-[#021B79] transition-colors duration-200',
    accent: 'text-green-500 hover:text-green-600 transition-colors duration-200',
  },
  text: {
    light: 'text-gray-800',
    dark: 'dark:text-gray-100',
  },
} as const;

// Helper function to combine classes
export const brandClasses = (...classes: string[]) => classes.filter(Boolean).join(' ');