import React, { useState, useEffect } from 'react';
import { Target, Sparkles, Package, CheckCircle, AlertCircle, Info, Loader2 } from 'lucide-react';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { supplementApi } from '../../api/supplementApi';
import { getTierBadge, formatPrice } from '../../utils/supplementHelpers';
import { Supplement, SupplementStack, RecommendationResponse } from '../../types/supplement';

const SupplementRecommendations: React.FC = () => {
  const [recommendations, setRecommendations] = useState<RecommendationResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [addingToCart, setAddingToCart] = useState<string | null>(null);

  useEffect(() => {
    loadRecommendations();
  }, []);

  const loadRecommendations = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await supplementApi.getPersonalizedRecommendations();
      setRecommendations(data);
    } catch (err) {
      console.error('Error loading recommendations:', err);
      setError('Failed to load personalized recommendations. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToCart = async (supplementId: string) => {
    setAddingToCart(supplementId);
    
    try {
      const success = await supplementApi.addToCart(supplementId, 1);
      if (success) {
        // Show success feedback
        setTimeout(() => setAddingToCart(null), 1000);
      } else {
        setAddingToCart(null);
        setError('Failed to add item to cart. Please try again.');
      }
    } catch (err) {
      console.error('Error adding to cart:', err);
      setAddingToCart(null);
      setError('Failed to add item to cart. Please try again.');
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <span className="ml-3 text-gray-600 dark:text-gray-400">Analyzing your health profile for the best supplement matches...</span>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="p-6 text-center">
        <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <div className="text-red-500 mb-4">
          <p className="font-medium">Unable to load recommendations</p>
          <p className="text-sm opacity-90 mt-1">{error}</p>
        </div>
        <Button onClick={loadRecommendations}>
          Try loading again
        </Button>
      </Card>
    );
  }

  if (!recommendations) {
    return (
      <Card className="p-6 text-center">
        <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
          Let's personalize your supplements
        </h3>
        <p className="text-gray-600 dark:text-gray-400">
          Complete your health profile to get evidence-based supplement recommendations tailored to your goals.
        </p>
        <Button className="mt-4">
          Complete your profile
        </Button>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 rounded-full bg-primary/10 mr-4">
            <Target className="w-8 h-8 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              Your Personalized Recommendations
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Based on your health profile and goals
            </p>
          </div>
        </div>
      </div>

      {/* Personalized Message */}
      {recommendations.personalized_message && (
        <Card className="p-6 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <div className="flex items-start">
            <Sparkles className="w-6 h-6 text-blue-600 dark:text-blue-400 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-blue-900 dark:text-blue-300 mb-2">
                Personalized Insights
              </h3>
              <p className="text-blue-800 dark:text-blue-400 leading-relaxed">
                {recommendations.personalized_message}
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Recommended Individual Supplements */}
      {recommendations.supplements && recommendations.supplements.length > 0 && (
        <section>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
            <CheckCircle className="w-6 h-6 text-green-500 mr-2" />
            Recommended Supplements
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {recommendations.supplements.map((supplement) => (
              <Card key={supplement.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="relative h-48 bg-gray-100 dark:bg-gray-800">
                  <img 
                    src={supplement.image_url || 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300'} 
                    alt={supplement.name} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    {getTierBadge(supplement.tier)}
                  </div>
                </div>
                
                <div className="p-4">
                  <h4 className="font-bold text-lg text-gray-900 dark:text-white mb-1">
                    {supplement.name}
                  </h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                    {supplement.brand || 'Biowell'} • {supplement.category}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300 mb-4 line-clamp-3">
                    {supplement.description}
                  </p>
                  
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="font-bold text-lg text-primary">
                      {formatPrice(supplement.price_aed || supplement.price)}
                    </span>
                    {supplement.subscription_discount_percent && supplement.subscription_discount_percent > 0 && (
                      <span className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300 rounded px-2 py-0.5 text-xs font-semibold">
                        {supplement.subscription_discount_percent}% off
                      </span>
                    )}
                  </div>
                  
                  <Button
                    onClick={() => handleAddToCart(supplement.id)}
                    disabled={addingToCart === supplement.id}
                    className="w-full"
                    aria-label={`Add ${supplement.name} to cart`}
                  >
                    {addingToCart === supplement.id ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Adding to cart...
                      </>
                    ) : (
                      `Add to cart • ${formatPrice(supplement.price_aed || supplement.price)}`
                    )}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Recommended Supplement Stacks */}
      {recommendations.stacks && recommendations.stacks.length > 0 && (
        <section>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
            <Package className="w-6 h-6 text-purple-500 mr-2" />
            Recommended Stacks
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {recommendations.stacks.map((stack) => (
              <Card key={stack.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="font-bold text-xl text-gray-900 dark:text-white mb-2">
                        {stack.name}
                      </h4>
                      <span className="inline-block px-3 py-1 bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300 rounded-full text-sm font-medium">
                        {stack.category}
                      </span>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">
                        {formatPrice(stack.total_price)}
                      </p>
                    </div>
                  </div>
                  
                  {stack.description && (
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      {stack.description}
                    </p>
                  )}
                  
                  <div className="space-y-2 mb-6">
                    <h5 className="font-medium text-gray-900 dark:text-white">Includes:</h5>
                    {Array.isArray(stack.components) ? (
                      stack.components.map((component, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-gray-700 dark:text-gray-300">
                            {component.name} ({component.dosage})
                          </span>
                          <span className="text-gray-500 dark:text-gray-400">
                            {formatPrice(component.price)}
                          </span>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Stack components information not available
                      </p>
                    )}
                  </div>
                  
                  <div className="flex gap-3">
                    <Button variant="outline" className="flex-1">
                      View Details
                    </Button>
                    <Button className="flex-1">
                      Add Stack to Cart
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* No Recommendations */}
      {(!recommendations.supplements || recommendations.supplements.length === 0) && 
       (!recommendations.stacks || recommendations.stacks.length === 0) && (
        <Card className="p-12 text-center">
          <Target className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            Ready for personalized recommendations?
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Tell us about your health goals and we'll recommend the most effective supplements for you.
          </p>
          <Button>
            Set up my health profile
          </Button>
        </Card>
      )}

      {/* Disclaimer */}
      <Card className="p-6 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
        <div className="flex items-start">
          <Info className="w-5 h-5 text-yellow-600 dark:text-yellow-400 mr-3 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="font-medium text-yellow-900 dark:text-yellow-300 mb-1">
              Before you start
            </h4>
            <p className="text-yellow-800 dark:text-yellow-400 text-sm">
              These recommendations are educational and not medical advice. Always consult your healthcare provider before starting supplements, especially if you take medications or have health conditions.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default SupplementRecommendations;