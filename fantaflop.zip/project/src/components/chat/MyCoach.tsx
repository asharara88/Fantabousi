import React, { useState, useEffect, useRef } from 'react';
import { Send, Mic, MicOff, Volume2, VolumeX, MessageCircle, Sparkles, Bot } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const httpsSupabaseUrl = supabaseUrl.replace(/^http:/, 'https:');
const supabase = createClient(httpsSupabaseUrl, supabaseAnonKey);

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface VoiceSettings {
  enabled: boolean;
  voiceId: string;
  speed: number;
  volume: number;
}

const QUESTION_SETS = [
  [
    "How can I improve my energy levels naturally?",
    "What supplements might help with my sleep quality?",
    "How do I optimize my workout routine?",
  ],
  [
    "What's the best way to track my health metrics?",
    "How can I reduce stress and improve mental clarity?",
    "What should I know about my circadian rhythm?",
  ],
  [
    "How do I create a sustainable nutrition plan?",
    "What are the most important vitamins for my age?",
    "How can I improve my recovery after workouts?",
  ]
];

export default function MyCoach() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    enabled: false,
    voiceId: 'default',
    speed: 1.0,
    volume: 1.0
  });
  const [currentQuestionSetIndex, setCurrentQuestionSetIndex] = useState(0);
  const [typingText, setTypingText] = useState('');
  const [isFetching, setIsFetching] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typingText]);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  // Welcome message
  useEffect(() => {
    const welcomeMessage: Message = {
      id: 'welcome',
      role: 'assistant',
      content: "Hello! I'm your AI health coach. I'm here to help you optimize your wellness journey with personalized guidance on nutrition, fitness, supplements, and overall health. What would you like to know today?",
      timestamp: new Date()
    };
    setMessages([welcomeMessage]);
  }, []);

  const startTypingAnimation = () => {
    const dots = ['', '.', '..', '...'];
    let index = 0;
    
    const animate = () => {
      setTypingText(`AI Coach is thinking${dots[index % dots.length]}`);
      index++;
      
      if (isFetching) {
        typingTimeoutRef.current = setTimeout(animate, 500);
      }
    };
    
    animate();
  };

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) {
      setError('Speech recognition is not supported in your browser.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  const playTextToSpeech = async (text: string) => {
    if (!voiceSettings.enabled) return;

    try {
      // Use browser's built-in speech synthesis as fallback
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = voiceSettings.speed;
      utterance.volume = voiceSettings.volume;
      speechSynthesis.speak(utterance);
    } catch (error) {
      console.error('Error playing text-to-speech:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent, questionText?: string) => {
    e.preventDefault();
    
    // Use either the provided question or the input field value
    const messageText = questionText || input.trim();
    if (!messageText || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: messageText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    if (!questionText) setInput('');
    setIsLoading(true);
    setError(null);
    setIsFetching(true);
    
    // Start typing animation
    startTypingAnimation();

    try {
      // Check if environment is properly configured
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseKey) {
        throw new Error('API configuration missing. Please check environment variables.');
      }

      // Call chat assistant function
      const { data, error: apiError } = await supabase.functions.invoke('chat-assistant', {
        body: {
          messages: [ 
            ...messages.map(m => ({ role: m.role, content: m.content })),
            { role: 'user', content: messageText }
          ]
        }
      });

      if (apiError) {
        console.error('Chat API error:', apiError);
        throw new Error(apiError.message || 'Failed to get AI response');
      }

      // Validate response
      const responseContent = data?.response || data?.message || "I'm sorry, I couldn't process that request right now. Please try again.";
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: responseContent,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Save to chat history
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (user) {
          await supabase.from('chat_history').insert([
            {
              user_id: user.id,
              message: messageText,
              response: responseContent,
              role: 'user',
              timestamp: new Date().toISOString()
            }
          ]);
        }
      } catch (chatError) {
        console.error('Error saving chat history:', chatError);
        // Continue even if saving chat history fails
      }

      // If voice is enabled, convert response to speech
      if (voiceSettings.enabled) {
        playTextToSpeech(responseContent);
      }
      
      // Stop typing animation
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      setTypingText('');
      setIsFetching(false);
      
      // Update question set after each response
      setCurrentQuestionSetIndex((prevIndex) => 
        (prevIndex + 1) % QUESTION_SETS.length
      );
      
    } catch (err) {
      console.error('Error sending message:', err);
      
      // More specific error messages
      if (err.message?.includes('configuration')) {
        setError('Service temporarily unavailable. Please try again in a moment.');
      } else if (err.message?.includes('network')) {
        setError('Connection issue. Please check your internet and try again.');
      } else {
        setError('Failed to get a response. Please try again.');
      }
      
      // Stop typing animation
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      setTypingText('');
      setIsFetching(false);
    } finally {
      setIsLoading(false);
    }
  };

  const currentQuestions = QUESTION_SETS[currentQuestionSetIndex];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-full mr-4">
            <Bot className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              MyCoach
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Your AI-powered health and wellness coach
            </p>
          </div>
        </div>
      </div>

      {/* Voice Settings */}
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setVoiceSettings(prev => ({ ...prev, enabled: !prev.enabled }))}
            >
              {voiceSettings.enabled ? (
                <Volume2 className="w-4 h-4 mr-2" />
              ) : (
                <VolumeX className="w-4 h-4 mr-2" />
              )}
              Voice Responses
            </Button>
          </div>
          
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {voiceSettings.enabled ? 'Voice enabled' : 'Voice disabled'}
          </div>
        </div>
      </Card>

      {/* Chat Messages */}
      <Card className="p-6 h-96 overflow-y-auto">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                  message.role === 'user'
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className="text-xs opacity-70 mt-1">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          
          {/* Typing indicator */}
          {typingText && (
            <div className="flex justify-start">
              <div className="bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white px-4 py-2 rounded-lg">
                <p className="text-sm italic">{typingText}</p>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </Card>

      {/* Quick Questions */}
      <Card className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3 flex items-center">
          <Sparkles className="w-5 h-5 mr-2 text-primary-600 dark:text-primary-400" />
          Quick Questions
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {currentQuestions.map((question, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={(e) => handleSubmit(e, question)}
              disabled={isLoading}
              className="text-left h-auto p-3 whitespace-normal"
            >
              {question}
            </Button>
          ))}
        </div>
      </Card>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
          <div className="text-red-700 dark:text-red-300">{error}</div>
        </div>
      )}

      {/* Input Form */}
      <Card className="p-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex space-x-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything about your health and wellness..."
              className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              disabled={isLoading}
            />
            
            {recognitionRef.current && (
              <Button
                type="button"
                variant="outline"
                onClick={toggleVoiceInput}
                disabled={isLoading}
                className={isListening ? 'bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-400' : ''}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
            )}
            
            <Button
              type="submit"
              disabled={isLoading || !input.trim()}
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          
          {isListening && (
            <div className="text-sm text-blue-600 dark:text-blue-400 flex items-center">
              <div className="animate-pulse w-2 h-2 bg-red-500 rounded-full mr-2"></div>
              Listening... Speak now
            </div>
          )}
        </form>
      </Card>
    </div>
  );
}