import React from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { Button } from '../ui/Button'

const CTA: React.FC = () => {
  const navigate = useNavigate()
  return (
    <motion.div
      className="mt-8 space-y-3"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.1 }}
    >
      <Button
        size="lg"
        className="bg-gradient-to-r from-primary-600 to-primary-700 hover:from-primary-700 hover:to-primary-800 text-white px-8 py-3 rounded-full shadow-elegant hover:shadow-premium transform hover:scale-105 transition-all duration-300"
        onClick={() => navigate('/onboarding')}
      >
        Start My Wellness Plan
      </Button>
    </motion.div>
  )
}

export default CTA
