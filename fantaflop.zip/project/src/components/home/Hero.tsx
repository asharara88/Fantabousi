import React from 'react'
import { motion } from 'framer-motion'

const Hero: React.FC = () => (
  <motion.div
    className="max-w-2xl space-y-4"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6 }}
  >
    <h1 className="text-5xl font-extrabold leading-tight text-gray-900 dark:text-white">
      Feel Better. <span className="text-primary-600 dark:text-primary-400">Every Day.</span>
    </h1>
    <p className="text-lg text-gray-600 dark:text-gray-300">
      Your Personalized Tool to Smarter Health and Performance
    </p>
  </motion.div>
)

export default Hero
