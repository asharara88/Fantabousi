import React from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'

const AuthPrompt: React.FC = () => (
  <motion.div
    className="mt-6 text-sm text-gray-500 dark:text-gray-400"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6, delay: 0.2 }}
  >
    Already have an account?{' '}
    <Link
      to="/login"
      className="text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300 underline transition-colors"
    >
      Log in
    </Link>
  </motion.div>
)

export default AuthPrompt
