import React from 'react'
import { motion } from 'framer-motion'

const HowItWorks: React.FC = () => (
  <motion.div
    className="mt-20 max-w-4xl text-left"
    initial={{ opacity: 0, y: 40 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6, delay: 1 }}
  >
    <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-6">How It Works</h2>
    <ol className="space-y-6 list-decimal list-inside text-gray-700 dark:text-gray-300">
      <li>
        <strong className="text-gray-900 dark:text-gray-100">Tell us about you:</strong> Answer a quick onboarding quiz about your goals, habits, and preferences.
      </li>
      <li>
        <strong className="text-gray-900 dark:text-gray-100">Sync your data:</strong> Connect wearables and health apps to personalize your insights.
      </li>
      <li>
        <strong className="text-gray-900 dark:text-gray-100">Meet your coach:</strong> Get AI-powered guidance and recommendations tailored to your data.
      </li>
      <li>
        <strong className="text-gray-900 dark:text-gray-100">Start your stack:</strong> Receive a personalized supplement plan backed by science and tracked in real time.
      </li>
      <li>
        <strong className="text-gray-900 dark:text-gray-100">Track and adjust:</strong> Let the system and your digital coach refine your plan as your data evolves.
      </li>
    </ol>
  </motion.div>
)

export default HowItWorks
