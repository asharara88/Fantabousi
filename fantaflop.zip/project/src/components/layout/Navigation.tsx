import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Button } from '../ui/Button';

const Navigation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, signOut } = useAuthStore();
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showSupplementsDropdown, setShowSupplementsDropdown] = useState(false);
  const [showNutritionDropdown, setShowNutritionDropdown] = useState(false);

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const isActive = (path: string) => location.pathname === path;

  const navigationItems = [
    { name: 'Dashboard', href: '/dashboard' },
    { name: 'Fitness', href: '/fitness' },
    { name: 'MyCoach', href: '/mycoach' },
    { 
      name: 'Nutrition', 
      href: '/nutrition',
      hasDropdown: true,
      dropdownItems: [
        { name: 'Food Logging', href: '/nutrition' },
        { name: 'MyPlate™', href: '/nutrition/myplate' },
        { name: 'Recipes', href: '/recipes' },
        { name: 'Saved Recipes', href: '/recipes/saved' }
      ]
    },
    { name: 'Metabolism', href: '/metabolism' },
    { 
      name: 'Supplements', 
      href: '/supplements',
      hasDropdown: true,
      dropdownItems: [
        { name: 'Browse Store', href: '/supplements' },
        { name: 'My Stacks', href: '/mystacks' },
        { name: 'Recommendations', href: '/supplements/recommendations' },
        { name: 'Cart', href: '/cart' }
      ]
    },
    { name: 'Pricing', href: '/pricing' }
  ];

  return (
    <nav className="bg-gray-900 border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to={user ? "/dashboard" : "/"} className="flex-shrink-0">
              <span className="text-xl font-bold text-white tracking-wide">
                BIOWELL
              </span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {user && navigationItems.map((item) => (
              <div key={item.name} className="relative">
                {item.hasDropdown ? (
                  <div className="relative">
                    <button
                      onClick={() => {
                        if (item.name === 'Supplements') {
                          setShowSupplementsDropdown(!showSupplementsDropdown);
                          setShowNutritionDropdown(false);
                        } else if (item.name === 'Nutrition') {
                          setShowNutritionDropdown(!showNutritionDropdown);
                          setShowSupplementsDropdown(false);
                        }
                      }}
                      className={`flex items-center px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                        item.dropdownItems?.some(dropdownItem => isActive(dropdownItem.href))
                          ? 'text-blue-400'
                          : 'text-gray-300 hover:text-white'
                      }`}
                    >
                      {item.name}
                      <ChevronDown className="w-4 h-4 ml-1" />
                    </button>

                    {/* Dropdown Menu */}
                    {((item.name === 'Supplements' && showSupplementsDropdown) || 
                      (item.name === 'Nutrition' && showNutritionDropdown)) && (
                      <div className="absolute top-full left-0 mt-1 w-48 bg-gray-800 border border-gray-700 rounded-md shadow-lg z-10">
                        {item.dropdownItems?.map((dropdownItem) => (
                          <Link
                            key={dropdownItem.href}
                            to={dropdownItem.href}
                            onClick={() => {
                              setShowSupplementsDropdown(false);
                              setShowNutritionDropdown(false);
                            }}
                            className={`block px-4 py-2 text-sm transition-colors ${
                              isActive(dropdownItem.href)
                                ? 'bg-gray-700 text-blue-400'
                                : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                            }`}
                          >
                            {dropdownItem.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    to={item.href}
                    className={`px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                      isActive(item.href)
                        ? 'text-blue-400'
                        : 'text-gray-300 hover:text-white'
                    }`}
                  >
                    {item.name}
                  </Link>
                )}
              </div>
            ))}
          </div>

          {/* Right Side - Auth */}
          <div className="flex items-center space-x-4">
            {user ? (
              <div className="hidden md:flex items-center space-x-3">
                <span className="text-sm text-gray-300">
                  {user.email}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleSignOut}
                  className="bg-transparent border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white"
                >
                  Sign Out
                </Button>
              </div>
            ) : (
              <div className="hidden md:flex items-center space-x-3">
                <Link
                  to="/login"
                  className="text-gray-300 hover:text-white text-sm font-medium transition-colors"
                >
                  Sign In
                </Link>
                <Button
                  as={Link}
                  to="/get-started"
                  size="sm"
                  className="bg-blue-600 hover:bg-blue-700 text-white border-blue-600"
                >
                  Get Started
                </Button>
              </div>
            )}

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setShowMobileMenu(!showMobileMenu)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
              >
                {showMobileMenu ? (
                  <X className="block h-6 w-6" />
                ) : (
                  <Menu className="block h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {showMobileMenu && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 border-t border-gray-800">
              {user && navigationItems.map((item) => (
                <div key={item.name}>
                  {item.hasDropdown ? (
                    <div>
                      <button
                        onClick={() => {
                          if (item.name === 'Supplements') {
                            setShowSupplementsDropdown(!showSupplementsDropdown);
                          } else if (item.name === 'Nutrition') {
                            setShowNutritionDropdown(!showNutritionDropdown);
                          }
                        }}
                        className="flex items-center justify-between w-full px-3 py-2 text-base font-medium text-gray-300 hover:text-white hover:bg-gray-800 rounded-md"
                      >
                        {item.name}
                        <ChevronDown className="w-4 h-4" />
                      </button>
                      
                      {((item.name === 'Supplements' && showSupplementsDropdown) || 
                        (item.name === 'Nutrition' && showNutritionDropdown)) && (
                        <div className="pl-4 mt-1 space-y-1">
                          {item.dropdownItems?.map((dropdownItem) => (
                            <Link
                              key={dropdownItem.href}
                              to={dropdownItem.href}
                              onClick={() => setShowMobileMenu(false)}
                              className={`block px-3 py-2 text-sm rounded-md transition-colors ${
                                isActive(dropdownItem.href)
                                  ? 'bg-gray-800 text-blue-400'
                                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
                              }`}
                            >
                              {dropdownItem.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <Link
                      to={item.href}
                      onClick={() => setShowMobileMenu(false)}
                      className={`block px-3 py-2 text-base font-medium rounded-md transition-colors ${
                        isActive(item.href)
                          ? 'bg-gray-800 text-blue-400'
                          : 'text-gray-300 hover:text-white hover:bg-gray-800'
                      }`}
                    >
                      {item.name}
                    </Link>
                  )}
                </div>
              ))}
              
              {user && (
                <div className="pt-4 border-t border-gray-800 mt-4">
                  <div className="px-3 py-2">
                    <div className="text-sm text-gray-400 mb-3">
                      {user.email}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleSignOut}
                      className="w-full bg-transparent border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white"
                    >
                      Sign Out
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Dropdown backdrop */}
      {(showSupplementsDropdown || showNutritionDropdown) && (
        <div
          className="fixed inset-0 z-0"
          onClick={() => {
            setShowSupplementsDropdown(false);
            setShowNutritionDropdown(false);
          }}
        />
      )}
    </nav>
  );
};

export default Navigation;