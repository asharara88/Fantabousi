import React from 'react';
import { Button } from '@/components/ui/Button';

const Hero = () => {
  return (
    <section className="pt-[env(safe-area-inset-top)] pb-[env(safe-area-inset-bottom)] text-center">
      <picture>
        <source
          srcSet="https://leznzqfezoofngumpiqf.supabase.co/storage/v1/object/sign/logos/white%20Log%20trnspt%20bg.svg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82ZjcyOGVhMS1jMTdjLTQ2MTYtOWFlYS1mZmI3MmEyM2U5Y2EiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJsb2dvcy93aGl0ZSBMb2cgdHJuc3B0IGJnLnN2ZyIsImlhdCI6MTc1MzA5NzIyMywiZXhwIjoxNzg0NjMzMjIzfQ.Rh9iofTrl1_l08P91isGUOekRcr0ckJYwT879TCL18A"
          media="(prefers-color-scheme: dark)"
        />
        <img
          src="https://leznzqfezoofngumpiqf.supabase.co/storage/v1/object/sign/logos/logo-light.svg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82ZjcyOGVhMS1jMTdjLTQ2MTYtOWFlYS1mZmI3MmEyM2U5Y2EiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJsb2dvcy9sb2dvLWxpZ2h0LnN2ZyIsImlhdCI6MTc1MzA5NzE5OCwiZXhwIjoxNzg0NjMzMTk4fQ.mF9VuwjuPx7d3oDExQadMsXppjApJRNkVMX5LZ5RoJM"
          alt="Biowell"
          className="mx-auto block w-[96px] md:w-[128px]"
          loading="eager"
          decoding="async"
          fetchPriority="high"
        />
      </picture>
      <div className="mt-6 flex justify-center w-full">
        <Button />
      </div>
    </section>
  );
};

export default Hero;
