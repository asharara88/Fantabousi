import React, { useState, useEffect } from 'react';
import { ChefHat, Clock, Users, Star, Heart, Bookmark } from 'lucide-react';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { recipeApi } from '../../api/recipeApi';

interface Recipe {
  id: number;
  title: string;
  image: string;
  readyInMinutes: number;
  servings: number;
  summary: string;
  healthScore: number;
  diets: string[];
  nutrition?: {
    calories: number;
    protein: number;
    fat: number;
    carbs: number;
  };
}

interface PersonalizedRecipesProps {
  preferences?: {
    diet?: string;
    intolerances?: string;
    maxCalories?: number;
    minProtein?: number;
  };
}

export default function PersonalizedRecipes({ preferences = {} }: PersonalizedRecipesProps) {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [savedRecipes, setSavedRecipes] = useState<Set<number>>(new Set());

  useEffect(() => {
    loadRecipes();
  }, [preferences]);

  const loadRecipes = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await recipeApi.searchRecipes(preferences);
      setRecipes(response.recipes);
    } catch (error) {
      console.error('Error loading recipes:', error);
      setError('Failed to load personalized recipes. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSaveRecipe = (recipeId: number) => {
    setSavedRecipes(prev => {
      const newSet = new Set(prev);
      if (newSet.has(recipeId)) {
        newSet.delete(recipeId);
      } else {
        newSet.add(recipeId);
      }
      return newSet;
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
        <span className="ml-3 text-gray-600 dark:text-gray-400">Loading personalized recipes...</span>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="p-6 text-center">
        <div className="text-red-600 dark:text-red-400 mb-4">{error}</div>
        <Button onClick={loadRecipes}>Try Again</Button>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Your Personalized Recipes
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Tailored to your dietary preferences and nutritional goals
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {recipes.map((recipe) => (
          <Card key={recipe.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <div className="relative">
              <img
                src={recipe.image}
                alt={recipe.title}
                className="w-full h-48 object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400';
                }}
              />
              <button
                onClick={() => toggleSaveRecipe(recipe.id)}
                className="absolute top-2 right-2 p-2 bg-white dark:bg-gray-800 rounded-full shadow-md hover:scale-110 transition-transform duration-200"
              >
                {savedRecipes.has(recipe.id) ? (
                  <Heart className="w-5 h-5 text-red-500 fill-current" />
                ) : (
                  <Heart className="w-5 h-5 text-gray-400" />
                )}
              </button>
            </div>

            <div className="p-4">
              <h3 className="font-semibold text-lg text-gray-900 dark:text-white mb-2 line-clamp-2">
                {recipe.title}
              </h3>

              <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-3">
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>{recipe.readyInMinutes} min</span>
                </div>
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1" />
                  <span>{recipe.servings} servings</span>
                </div>
                <div className="flex items-center">
                  <Star className="w-4 h-4 mr-1 text-yellow-500" />
                  <span>{recipe.healthScore}</span>
                </div>
              </div>

              {recipe.nutrition && (
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 mb-3">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-gray-500 dark:text-gray-400">Calories:</span>
                      <span className="ml-1 font-medium">{Math.round(recipe.nutrition.calories)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 dark:text-gray-400">Protein:</span>
                      <span className="ml-1 font-medium">{Math.round(recipe.nutrition.protein)}g</span>
                    </div>
                    <div>
                      <span className="text-gray-500 dark:text-gray-400">Carbs:</span>
                      <span className="ml-1 font-medium">{Math.round(recipe.nutrition.carbs)}g</span>
                    </div>
                    <div>
                      <span className="text-gray-500 dark:text-gray-400">Fat:</span>
                      <span className="ml-1 font-medium">{Math.round(recipe.nutrition.fat)}g</span>
                    </div>
                  </div>
                </div>
              )}

              {recipe.diets.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-3">
                  {recipe.diets.slice(0, 3).map((diet) => (
                    <span
                      key={diet}
                      className="px-2 py-1 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 text-xs rounded-full"
                    >
                      {diet}
                    </span>
                  ))}
                </div>
              )}

              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => window.open(`/recipes/${recipe.id}`, '_blank')}
              >
                <ChefHat className="w-4 h-4 mr-2" />
                View Recipe
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {recipes.length === 0 && (
        <Card className="p-8 text-center">
          <ChefHat className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No recipes found
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Try adjusting your dietary preferences or search criteria.
          </p>
        </Card>
      )}
    </div>
  );
}