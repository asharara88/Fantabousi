export const BRAND_COLORS = {
  gradient: {
    start: '#0575E6',
    end: '#021B79',
    class: 'from-[#0575E6] to-[#021B79]'
  },
  accent: {
    DEFAULT: '#22c55e',
    focus: 'focus:ring-green-500',
  },
  dark: '#f9fafb',
};

// Reusable class segments for maintainability
const GRADIENT_CLASS = 'bg-gradient-to-br from-[#0575E6] to-[#021B79]';
const TEXT_WHITE_CLASS = 'text-white';
const HOVER_SHADOW_CLASS = 'hover:shadow-lg';
const FOCUS_RING_CLASS = 'focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2';

export const BRAND_CLASSES = {
  button: {
    primary: `${GRADIENT_CLASS} ${TEXT_WHITE_CLASS} ${HOVER_SHADOW_CLASS} ${FOCUS_RING_CLASS}`,
    secondary: 'bg-gray-200 text-gray-900 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-100 dark:hover:bg-gray-600 ' + FOCUS_RING_CLASS,
    ghost: 'bg-transparent hover:bg-gray-100 dark:hover:bg-gray-800 ' + FOCUS_RING_CLASS,
  },
  card: {
    hover: 'hover:ring-2 hover:ring-green-500/30 hover:shadow-green-500/10'
  },
  focus: FOCUS_RING_CLASS,
  accent: {
    focus: 'focus:ring-green-500',
    hover: 'hover:ring-green-500/30',
  }
};