import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import ErrorBoundary from './components/ui/ErrorBoundary';

// Layout Components
import Layout from './components/layout/Layout';

// Public Pages
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import LoginPage from './pages/auth/LoginPage';
import SignupPage from './pages/auth/SignupPage';
import GetStartedPage from './pages/auth/GetStartedPage';
import OnboardingPage from './pages/auth/OnboardingPage';

// Protected Pages
import DashboardPage from './pages/DashboardPage';
import MyCoachPage from './pages/MyCoachPage';
import NutritionPage from './pages/NutritionPage';
import NutritionDashboardPage from './pages/NutritionDashboardPage';
import MyPlatePage from './pages/MyPlatePage';
import RecipesPage from './pages/RecipesPage';
import RecipeDetailPage from './pages/RecipeDetailPage';
import SavedRecipesPage from './pages/SavedRecipesPage';
import FitnessPage from './pages/FitnessPage';
import SleepPage from './pages/SleepPage';
import SupplementsPage from './pages/SupplementsPage';
import SupplementStorePage from './pages/SupplementStorePage';
import SupplementDetailPage from './pages/SupplementDetailPage';
import MyStacksPage from './pages/MyStacksPage';
import SupplementRecommendationsPage from './pages/SupplementRecommendationsPage';
import MetabolismPage from './pages/MetabolismPage';
import MyBioPage from './pages/MyBioPage';
import BioclockPage from './pages/BioclockPage';
import CartPage from './pages/CartPage';
import NotFoundPage from './pages/NotFoundPage';

// Debug Pages
import EnvCheckPage from './pages/debug/EnvCheckPage';

// Protected Route Component
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuthStore();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return <Layout>{children}</Layout>;
};

const App: React.FC = () => {
  const { loading } = useAuthStore();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/get-started" element={<GetStartedPage />} />
          
          {/* Onboarding (requires auth) */}
          <Route path="/onboarding" element={
            <ProtectedRoute>
              <OnboardingPage />
            </ProtectedRoute>
          } />
          
          {/* Protected Dashboard Routes */}
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          } />
          
          <Route path="/mycoach" element={
            <ProtectedRoute>
              <MyCoachPage />
            </ProtectedRoute>
          } />
          
          {/* Health Tracking Routes */}
          <Route path="/nutrition" element={
            <ProtectedRoute>
              <NutritionPage />
            </ProtectedRoute>
          } />
          
          <Route path="/nutrition/dashboard" element={
            <ProtectedRoute>
              <NutritionDashboardPage />
            </ProtectedRoute>
          } />
          
          <Route path="/nutrition/myplate" element={
            <ProtectedRoute>
              <MyPlatePage />
            </ProtectedRoute>
          } />
          
          <Route path="/recipes" element={
            <ProtectedRoute>
              <RecipesPage />
            </ProtectedRoute>
          } />
          
          <Route path="/recipes/:id" element={
            <ProtectedRoute>
              <RecipeDetailPage />
            </ProtectedRoute>
          } />
          
          <Route path="/recipes/saved" element={
            <ProtectedRoute>
              <SavedRecipesPage />
            </ProtectedRoute>
          } />
          
          <Route path="/fitness" element={
            <ProtectedRoute>
              <FitnessPage />
            </ProtectedRoute>
          } />
          
          <Route path="/sleep" element={
            <ProtectedRoute>
              <SleepPage />
            </ProtectedRoute>
          } />
          
          <Route path="/metabolism" element={
            <ProtectedRoute>
              <MetabolismPage />
            </ProtectedRoute>
          } />
          
          <Route path="/mybio" element={
            <ProtectedRoute>
              <MyBioPage />
            </ProtectedRoute>
          } />
          
          <Route path="/bioclock" element={
            <ProtectedRoute>
              <BioclockPage />
            </ProtectedRoute>
          } />
          
          {/* Supplement Routes */}
          <Route path="/supplements" element={
            <ProtectedRoute>
              <SupplementsPage />
            </ProtectedRoute>
          } />
          
          <Route path="/supplement-store" element={
            <ProtectedRoute>
              <SupplementStorePage />
            </ProtectedRoute>
          } />
          
          <Route path="/supplements/:id" element={
            <ProtectedRoute>
              <SupplementDetailPage />
            </ProtectedRoute>
          } />
          
          <Route path="/mystacks" element={
            <ProtectedRoute>
              <MyStacksPage />
            </ProtectedRoute>
          } />
          
          <Route path="/supplements/recommendations" element={
            <ProtectedRoute>
              <SupplementRecommendationsPage />
            </ProtectedRoute>
          } />
          
          <Route path="/cart" element={
            <ProtectedRoute>
              <CartPage />
            </ProtectedRoute>
          } />
          
          {/* Debug Routes */}
          <Route path="/debug/env" element={
            <ProtectedRoute>
              <EnvCheckPage />
            </ProtectedRoute>
          } />
          
          {/* Catch all route */}
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </Router>
    </ErrorBoundary>
  );
};

export default App;