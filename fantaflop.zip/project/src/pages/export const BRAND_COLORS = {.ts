export const BRAND_COLORS = {
  gradient: {
    start: '#0575E6',
    end: '#021B79',
    class: 'from-[#0575E6] to-[#021B79]',
  },
  accent: {
    DEFAULT: '#22c55e',
    focus: 'focus:ring-green-500',
    hover: 'hover:ring-green-500/30',
  },
  text: {
    light: '#1f2937',
    dark: '#f9fafb',
  },
} as const;

export const BRAND_CLASSES = {
  button: {
    primary: 'bg-gradient-to-br from-[#0575E6] to-[#021B79] text-white hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2',
    secondary: 'bg-gray-200 text-gray-900 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-100 dark:hover:bg-gray-600',
  },
  card: {
    hover: 'hover:ring-2 hover:ring-green-500/30 hover:shadow-green-500/10',
  },
  focus: 'focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2',
} as const;