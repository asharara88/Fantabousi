import React from 'react';
import { Utensils, Plus, TrendingUp, Apple } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const NutritionPage: React.FC = () => {
  const nutritionMetrics = [
    {
      name: 'Daily Calories',
      value: '1,850',
      target: '2,200',
      percentage: 84
    },
    {
      name: 'Protein',
      value: '95g',
      target: '120g',
      percentage: 79
    },
    {
      name: 'Carbs',
      value: '210g',
      target: '250g',
      percentage: 84
    },
    {
      name: 'Fat',
      value: '65g',
      target: '73g',
      percentage: 89
    }
  ];

  const recentMeals = [
    {
      id: 1,
      name: 'Greek Yogurt with Berries',
      type: 'Breakfast',
      calories: 280,
      time: '8:30 AM'
    },
    {
      id: 2,
      name: 'Grilled Chicken Salad',
      type: 'Lunch',
      calories: 420,
      time: '1:15 PM'
    },
    {
      id: 3,
      name: 'Protein Smoothie',
      type: 'Snack',
      calories: 190,
      time: '3:45 PM'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-6 sm:py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Nutrition Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400">Track your daily nutrition and meal plans</p>
        </div>

        {/* Nutrition Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {nutritionMetrics.map((metric, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400">
                    {metric.name}
                  </h3>
                  <Apple className="w-5 h-5 text-green-500" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-baseline space-x-2">
                    <span className="text-2xl font-bold text-gray-900 dark:text-white">
                      {metric.value}
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      / {metric.target}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${metric.percentage}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-green-600 dark:text-green-400">
                    {metric.percentage}% of goal
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Today's Meals */}
          <div className="lg:col-span-2">
            <Card className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Today's Meals</h2>
                <Button className="flex items-center">
                  <Plus className="w-4 h-4 mr-2" />
                  Log Meal
                </Button>
              </div>
              
              <div className="space-y-4">
                {recentMeals.map((meal) => (
                  <div
                    key={meal.id}
                    className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  >
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">{meal.name}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{meal.type} • {meal.time}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900 dark:text-white">{meal.calories} cal</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Nutrition Goals */}
          <div>
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">Today's Goals</h2>
              
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Water Intake</span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">6/8 glasses</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Vegetable Servings</span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">3/5 servings</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '60%' }}></div>
                  </div>
                </div>

                <Button className="w-full">
                  View Meal Recommendations
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NutritionPage;