import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Shield, Brain, Target } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: <Shield className="w-8 h-8 text-blue-600" />,
      title: 'Evidence-Based',
      description: 'All recommendations backed by clinical research and peer-reviewed studies.'
    },
    {
      icon: <Brain className="w-8 h-8 text-blue-600" />,
      title: 'AI-Powered',
      description: 'Personalized insights using advanced AI to optimize your health journey.'
    },
    {
      icon: <Target className="w-8 h-8 text-blue-600" />,
      title: 'Goal-Oriented',
      description: 'Tailored recommendations based on your specific health and wellness goals.'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 px-4 text-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
            <div className="h-16 sm:h-20 lg:h-24 mx-auto mb-4 flex items-center justify-center">
              {/* Light theme logo */}
              <img 
                src="https://leznzqfezoofngumpiqf.supabase.co/storage/v1/object/sign/logos/logo-light.svg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82ZjcyOGVhMS1jMTdjLTQ2MTYtOWFlYS1mZmI3MmEyM2U5Y2EiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJsb2dvcy9sb2dvLWxpZ2h0LnN2ZyIsImlhdCI6MTc1MzA5NzE5OCwiZXhwIjoxNzg0NjMzMTk4fQ.mF9VuwjuPx7d3oDExQadMsXppjApJRNkVMX5LZ5RoJM"
                alt="Biowell" 
                className="h-full w-auto object-contain dark:hidden"
                loading="eager"
                decoding="async"
                fetchPriority="high"
              />
              {/* Dark theme logo */}
              <img 
                src="https://leznzqfezoofngumpiqf.supabase.co/storage/v1/object/sign/logos/white%20Log%20trnspt%20bg.svg?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82ZjcyOGVhMS1jMTdjLTQ2MTYtOWFlYS1mZmI3MmEyM2U5Y2EiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJsb2dvcy93aGl0ZSBMb2cgdHJuc3B0IGJnLnN2ZyIsImlhdCI6MTc1MzA5NzIyMywiZXhwIjoxNzg0NjMzMjIzfQ.Rh9iofTrl1_l08P91isGUOekRcr0ckJYwT879TCL18A"
                alt="Biowell" 
                className="h-full w-auto object-contain hidden dark:block"
                loading="eager"
                decoding="async"
                fetchPriority="high"
              />
            </div>
            Your Personal <span className="text-blue-600">Health Coach</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
            AI-powered wellness platform with evidence-based supplements, 
            personalized nutrition, and comprehensive health tracking.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button as={Link} to="/signup" size="lg" className="px-8">
              Get Started Free
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button as={Link} to="/login" variant="outline" size="lg">
              Sign In
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Science-Driven Health Optimization
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300">
              Every recommendation is backed by research and tailored to your unique profile
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300">
                <div className="p-6">
                  <div className="flex justify-center mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {feature.description}
                  </p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gray-100 dark:bg-gray-800">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Ready to optimize your health?
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
            Join thousands of users who have transformed their wellness with Biowell AI
          </p>
          <Button as={Link} to="/signup" size="lg" className="px-8">
            Start Your Journey
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>
    </div>
  );
};

export default HomePage;