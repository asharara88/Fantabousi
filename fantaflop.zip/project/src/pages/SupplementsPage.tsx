import React, { useState } from 'react';
import { Package, Search, Filter, Star, ShoppingCart } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';

const SupplementsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', name: 'All Supplements' },
    { id: 'fitness', name: 'Fitness & Performance' },
    { id: 'health', name: 'General Health' },
    { id: 'sleep', name: 'Sleep & Recovery' },
    { id: 'cognitive', name: 'Cognitive Support' },
    { id: 'immune', name: 'Immune Support' }
  ];

  const supplements = [
    {
      id: 1,
      name: 'Omega-3 Fish Oil',
      category: 'health',
      price: 49.99,
      rating: 4.8,
      tier: 'green',
      description: 'High-quality EPA/DHA for heart and brain health',
      image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: 2,
      name: 'Magnesium Glycinate',
      category: 'sleep',
      price: 34.99,
      rating: 4.7,
      tier: 'green',
      description: 'Premium magnesium for better sleep and recovery',
      image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: 3,
      name: 'Creatine Monohydrate',
      category: 'fitness',
      price: 29.99,
      rating: 4.9,
      tier: 'green',
      description: 'Pure creatine for strength and performance',
      image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: 4,
      name: 'Vitamin D3',
      category: 'health',
      price: 24.99,
      rating: 4.6,
      tier: 'green',
      description: 'Essential vitamin for immune and bone health',
      image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: 5,
      name: 'Lion\'s Mane Mushroom',
      category: 'cognitive',
      price: 39.99,
      rating: 4.5,
      tier: 'yellow',
      description: 'Cognitive support and brain health',
      image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    {
      id: 6,
      name: 'Probiotics Complex',
      category: 'health',
      price: 44.99,
      rating: 4.4,
      tier: 'green',
      description: 'Multi-strain probiotics for gut health',
      image: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg?auto=compress&cs=tinysrgb&w=300'
    }
  ];

  const getTierBadge = (tier: string) => {
    const colors = {
      green: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300',
      yellow: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300',
      orange: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300'
    };
    
    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${colors[tier] || colors.green}`}>
        {tier.charAt(0).toUpperCase() + tier.slice(1)} Tier
      </span>
    );
  };

  const filteredSupplements = supplements.filter(supplement => {
    const matchesSearch = supplement.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || supplement.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-6 sm:py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Supplement Store</h1>
          <p className="text-gray-600 dark:text-gray-400">Evidence-based supplements for optimal health</p>
        </div>

        {/* Search and Filters */}
        <Card className="p-6 mb-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search supplements..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-2 overflow-x-auto">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                    selectedCategory === category.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Supplements Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredSupplements.map((supplement) => (
            <Card key={supplement.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
              <div className="relative">
                <img 
                  src={supplement.image} 
                  alt={supplement.name} 
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-2 left-2">
                  {getTierBadge(supplement.tier)}
                </div>
                <div className="absolute top-2 right-2">
                  <div className="bg-white dark:bg-gray-800 rounded-full px-2 py-1 flex items-center">
                    <Star className="w-3 h-3 text-yellow-500 mr-1" />
                    <span className="text-xs font-medium">{supplement.rating}</span>
                  </div>
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">
                  {supplement.name}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">
                  {supplement.description}
                </p>
                
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xl font-bold text-blue-600">
                    ${supplement.price}
                  </span>
                </div>
                
                <Button className="w-full flex items-center justify-center">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Add to Cart
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {filteredSupplements.length === 0 && (
          <Card className="p-12 text-center">
            <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              No supplements found
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Try adjusting your search terms or filters
            </p>
          </Card>
        )}
      </div>
    </div>
  );
};

export default SupplementsPage;