import React, { useEffect, useState } from 'react';
import { Activity, Heart, Brain, TrendingUp, Pill, Utensils, Moon, Target, Zap, Droplets } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { useAuthStore } from '@/store/authStore';
import BWScoreCard from '@/components/dashboard/BWScoreCard';
import ActivityTimeline from '@/components/dashboard/ActivityTimeline';
import SupplementTracker from '@/components/dashboard/SupplementTracker';
import FitnessWidget from '@/components/fitness/FitnessWidget';
import { MetricScore } from '@/components/dashboard/BWScoreCard';
import { Link } from 'react-router-dom';

const DashboardPage: React.FC = () => {
  const { user } = useAuthStore();
  const [expandedWidget, setExpandedWidget] = useState<string | null>(null);

  // Mock health metrics for BW Score calculation
  const healthMetrics: MetricScore[] = [
    {
      name: 'Sleep Quality',
      score: 85,
      weight: 1.5, // Higher weight for sleep
      color: '#8b5cf6',
      icon: <Moon className="w-4 h-4" />,
      description: 'Based on sleep duration, quality, and consistency patterns'
    },
    {
      name: 'Fitness Level',
      score: 78,
      weight: 1.5, // Higher weight for fitness
      color: '#3b82f6',
      icon: <Activity className="w-4 h-4" />,
      description: 'Workout frequency, intensity, and recovery metrics'
    },
    {
      name: 'Nutrition Score',
      score: 72,
      weight: 1.3,
      color: '#10b981',
      icon: <Utensils className="w-4 h-4" />,
      description: 'Macro balance, micronutrient intake, and meal timing'
    },
    {
      name: 'Supplement Adherence',
      score: 90,
      weight: 1.0,
      color: '#f59e0b',
      icon: <Pill className="w-4 h-4" />,
      description: 'Consistency with supplement regimen and timing'
    },
    {
      name: 'Stress Management',
      score: 68,
      weight: 1.2,
      color: '#ef4444',
      icon: <Brain className="w-4 h-4" />,
      description: 'Stress levels, recovery practices, and mental wellness'
    },
    {
      name: 'Hydration',
      score: 82,
      weight: 0.8, // Lower weight for hydration
      color: '#06b6d4',
      icon: <Droplets className="w-4 h-4" />,
      description: 'Daily water intake and hydration consistency'
    }
  ];

  // Mock activity timeline data
  const todayActivities = [
    {
      id: '1',
      time: '7:00 AM',
      title: 'Morning Supplements',
      description: 'Vitamin D3, Omega-3, Magnesium',
      type: 'supplement' as const
    },
    {
      id: '2',
      time: '8:30 AM',
      title: 'Breakfast Logged',
      description: 'Greek yogurt with berries and granola',
      type: 'meal' as const
    },
    {
      id: '3',
      time: '10:00 AM',
      title: 'Morning Workout',
      description: '45-min strength training session',
      type: 'workout' as const
    },
    {
      id: '4',
      time: '12:30 PM',
      title: 'Lunch Logged',
      description: 'Grilled chicken salad with quinoa',
      type: 'meal' as const
    },
    {
      id: '5',
      time: '3:00 PM',
      title: 'Hydration Check',
      description: '6/8 glasses of water completed',
      type: 'water' as const
    },
    {
      id: '6',
      time: '6:00 PM',
      title: 'Evening Supplements',
      description: 'Magnesium, Melatonin',
      type: 'supplement' as const
    }
  ];

  // Mock supplement tracker data
  const todaySupplements = [
    {
      id: '1',
      name: 'Vitamin D3',
      dosage: '5000 IU',
      timing: 'With breakfast',
      taken: true,
      timeOfDay: 'morning' as const
    },
    {
      id: '2',
      name: 'Omega-3 Fish Oil',
      dosage: '1000mg',
      timing: 'With breakfast',
      taken: true,
      timeOfDay: 'morning' as const
    },
    {
      id: '3',
      name: 'Magnesium Glycinate',
      dosage: '400mg',
      timing: 'Before bed',
      taken: false,
      timeOfDay: 'bedtime' as const
    },
    {
      id: '4',
      name: 'Ashwagandha',
      dosage: '600mg',
      timing: 'With dinner',
      taken: false,
      timeOfDay: 'evening' as const
    }
  ];

  const handleMarkSupplementTaken = (supplementId: string) => {
    // In a real app, this would update the database
    console.log('Marked supplement as taken:', supplementId);
  };

  const handleMetricClick = (metricName: string) => {
    // Navigate to specific metric page
    switch (metricName) {
      case 'Sleep Quality':
        window.location.href = '/sleep';
        break;
      case 'Fitness Level':
        window.location.href = '/fitness';
        break;
      case 'Nutrition Score':
        window.location.href = '/nutrition';
        break;
      case 'Supplement Adherence':
        window.location.href = '/supplements';
        break;
      default:
        break;
    }
  };

  const quickActions = [
    {
      title: 'Chat with MyCoach™',
      description: 'Get personalized health advice from your AI coach',
      href: '/mycoach',
      icon: <Brain className="w-6 h-6 text-blue-600" />,
      color: 'bg-blue-50 dark:bg-blue-900/20'
    },
    {
      title: 'Log Food',
      description: 'Track your meals and nutrition',
      href: '/nutrition/myplate',
      icon: <Utensils className="w-6 h-6 text-green-600" />,
      color: 'bg-green-50 dark:bg-green-900/20'
    },
    {
      title: 'Log Workout',
      description: 'Record your fitness activities',
      href: '/fitness',
      icon: <Activity className="w-6 h-6 text-purple-600" />,
      color: 'bg-purple-50 dark:bg-purple-900/20'
    },
    {
      title: 'View Recommendations',
      description: 'See your personalized supplement suggestions',
      href: '/supplements/recommendations',
      icon: <Target className="w-6 h-6 text-orange-600" />,
      color: 'bg-orange-50 dark:bg-orange-900/20'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-6 sm:py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Welcome back, {user?.firstName || 'there'}!
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Here's your health overview for today
          </p>
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* BW Score Card - Takes up 1 column */}
          <div className="lg:col-span-1">
            <BWScoreCard 
              metrics={healthMetrics}
              onMetricClick={handleMetricClick}
            />
          </div>

          {/* Activity Timeline - Takes up 2 columns */}
          <div className="lg:col-span-2">
            <ActivityTimeline events={todayActivities} />
          </div>
        </div>

        {/* Secondary Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Supplement Tracker */}
          <SupplementTracker 
            supplements={todaySupplements}
            onMarkTaken={handleMarkSupplementTaken}
          />

          {/* Fitness Widget */}
          <FitnessWidget 
            expanded={expandedWidget === 'fitness'}
            onToggle={() => setExpandedWidget(expandedWidget === 'fitness' ? null : 'fitness')}
          />
        </div>

        {/* Quick Actions */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <Link
                key={index}
                to={action.href}
                className="group p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all duration-200 hover:border-blue-300 dark:hover:border-blue-600"
              >
                <div className={`p-3 rounded-lg ${action.color} mb-3 inline-flex`}>
                  {action.icon}
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {action.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {action.description}
                </p>
              </Link>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default DashboardPage;