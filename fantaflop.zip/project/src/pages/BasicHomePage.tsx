import React from "react";

export default function HomePage() {
  return (
    <div className="p-6 flex flex-col items-center justify-center text-center space-y-6">
      <div className="space-y-2">
        <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">
          Powered by AI • Evidence-Based • Personalized
        </span>
        <h1 className="text-4xl font-bold">Your Personal <span className="text-blue-500">Wellness Coach</span></h1>
        <p className="text-lg text-gray-600">
          Optimize yourself everyday. AI-powered wellness coaching with evidence-based supplements, real-time health tracking, and personalized optimization.
        </p>
      </div>

      {/* CTA Button */}
      <button className="bg-blue-600 text-white px-6 py-3 rounded-md shadow hover:bg-blue-700 transition">
        Get Started
      </button>

      {/* Conventional Sign In */}
      <div className="text-sm text-gray-600 pt-4">
        Already have an account? <a href="/login" className="text-blue-500 underline">Sign in</a>
      </div>
    </div>
  );
}

