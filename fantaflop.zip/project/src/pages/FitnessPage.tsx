import React, { useState } from 'react';
import { Activity, Plus, TrendingUp, Clock, Zap } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

const FitnessPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');

  const fitnessMetrics = [
    {
      name: 'Weekly Workouts',
      value: '4',
      change: '+2 from last week',
      icon: <Activity className="w-6 h-6 text-blue-500" />
    },
    {
      name: 'Total Active Time',
      value: '3.5h',
      change: '+45 min this week',
      icon: <Clock className="w-6 h-6 text-green-500" />
    },
    {
      name: 'Calories Burned',
      value: '1,240',
      change: '+180 this week',
      icon: <Zap className="w-6 h-6 text-orange-500" />
    },
    {
      name: 'Fitness Score',
      value: '82',
      change: '+5 points',
      icon: <TrendingUp className="w-6 h-6 text-purple-500" />
    }
  ];

  const recentWorkouts = [
    {
      id: 1,
      name: 'Upper Body Strength',
      date: 'Today',
      duration: '45 min',
      calories: 320
    },
    {
      id: 2,
      name: 'HIIT Cardio',
      date: 'Yesterday',
      duration: '30 min',
      calories: 280
    },
    {
      id: 3,
      name: 'Lower Body Strength',
      date: '2 days ago',
      duration: '50 min',
      calories: 380
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-6 sm:py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Fitness Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400">Track your workouts and monitor your progress</p>
        </div>

        {/* Fitness Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {fitnessMetrics.map((metric, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {metric.name}
                    </p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {metric.value}
                    </p>
                    <p className="text-sm text-green-600 dark:text-green-400">
                      {metric.change}
                    </p>
                  </div>
                  <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-full">
                    {metric.icon}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Workouts */}
          <div className="lg:col-span-2">
            <Card className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Recent Workouts</h2>
                <Button className="flex items-center">
                  <Plus className="w-4 h-4 mr-2" />
                  Log Workout
                </Button>
              </div>
              
              <div className="space-y-4">
                {recentWorkouts.map((workout) => (
                  <div
                    key={workout.id}
                    className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  >
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">{workout.name}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{workout.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900 dark:text-white">{workout.duration}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{workout.calories} cal</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Workout Plan */}
          <div>
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">Today's Plan</h2>
              
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h3 className="font-medium text-blue-900 dark:text-blue-300 mb-2">
                    Scheduled: Lower Body
                  </h3>
                  <p className="text-sm text-blue-800 dark:text-blue-400">
                    45 minutes • Strength training
                  </p>
                  <Button size="sm" className="mt-3 w-full">
                    Start Workout
                  </Button>
                </div>
                
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <h3 className="font-medium text-gray-900 dark:text-white mb-2">
                    Weekly Goal Progress
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Workouts</span>
                      <span>4/5</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: '80%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FitnessPage;