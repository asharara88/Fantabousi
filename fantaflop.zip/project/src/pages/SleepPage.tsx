import React from 'react';
import { Moon, Clock, TrendingUp, Zap } from 'lucide-react';
import { Card } from '@/components/ui/Card';

const SleepPage: React.FC = () => {
  const sleepMetrics = [
    {
      name: 'Last Night',
      value: '7h 45m',
      quality: 'Good',
      icon: <Moon className="w-6 h-6 text-purple-500" />
    },
    {
      name: 'Deep Sleep',
      value: '1h 20m',
      quality: 'Excellent',
      icon: <Clock className="w-6 h-6 text-blue-500" />
    },
    {
      name: 'Sleep Score',
      value: '85',
      quality: 'Good',
      icon: <TrendingUp className="w-6 h-6 text-green-500" />
    },
    {
      name: 'Energy Level',
      value: '92%',
      quality: 'High',
      icon: <Zap className="w-6 h-6 text-yellow-500" />
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-6 sm:py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Sleep Tracking</h1>
          <p className="text-gray-600 dark:text-gray-400">Monitor and optimize your sleep for better health</p>
        </div>

        {/* Sleep Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {sleepMetrics.map((metric, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <div className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {metric.name}
                    </p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {metric.value}
                    </p>
                    <p className="text-sm text-green-600 dark:text-green-400">
                      {metric.quality}
                    </p>
                  </div>
                  <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-full">
                    {metric.icon}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Sleep Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="p-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">Sleep Stages</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-700 dark:text-gray-300">Deep Sleep</span>
                <span className="font-medium">1h 20m (17%)</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700 dark:text-gray-300">REM Sleep</span>
                <span className="font-medium">1h 35m (20%)</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-700 dark:text-gray-300">Light Sleep</span>
                <span className="font-medium">4h 50m (63%)</span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">Sleep Insights</h2>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <p className="text-sm text-green-800 dark:text-green-300">
                  ✓ Your sleep duration is within the optimal range
                </p>
              </div>
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <p className="text-sm text-blue-800 dark:text-blue-300">
                  💡 Try maintaining a consistent bedtime to improve sleep quality
                </p>
              </div>
              <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                <p className="text-sm text-yellow-800 dark:text-yellow-300">
                  ⚠ Consider reducing screen time 1 hour before bed
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SleepPage;