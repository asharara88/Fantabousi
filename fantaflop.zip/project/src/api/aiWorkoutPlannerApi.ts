import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const httpsSupabaseUrl = supabaseUrl.replace(/^http:/, 'https:');
const supabase = createClient(httpsSupabaseUrl, supabaseAnonKey);

export interface Exercise {
  id: string;
  name: string;
  description: string;
  sets: number;
  reps: string;
  muscleGroups: string[];
  equipment: string[];
  instructions: string[];
}

export interface WorkoutPlan {
  id: string;
  name: string;
  description: string;
  duration: number;
  difficulty: string;
  exercises: Exercise[];
  targetMuscles: string[];
}

export const aiWorkoutPlannerApi = {
  // Generate personalized workout plan
  generateWorkoutPlan: async (preferences: {
    goal: string;
    experience: string;
    duration: number;
    equipment?: string[];
    targetMuscles?: string[];
  }): Promise<WorkoutPlan | null> => {
    try {
      // Check environment configuration
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (!supabaseUrl) {
        console.warn('Supabase URL not configured, returning mock workout plan');
        return getMockWorkoutPlan(preferences);
      }

      const { data, error } = await supabase.functions.invoke('ai-workout-planner', {
        body: {
          endpoint: 'generate-workout-plan',
          data: preferences
        }
      });
      
      if (error) {
        console.error('Workout planner API error:', error);
        return getMockWorkoutPlan(preferences);
      }
      
      return data;
    } catch (error) {
      console.error('Error generating workout plan:', error);
      return getMockWorkoutPlan(preferences);
    }
  },

  // Get exercise recommendations
  getExerciseRecommendations: async (muscleGroup: string, equipment?: string[]): Promise<Exercise[]> => {
    try {
      // Check environment configuration
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (!supabaseUrl) {
        console.warn('Supabase URL not configured, returning mock exercises');
        return getMockExercises(muscleGroup);
      }

      const { data, error } = await supabase.functions.invoke('ai-workout-planner', {
        body: {
          endpoint: 'get-exercises',
          data: { muscleGroup, equipment }
        }
      });
      
      if (error) {
        console.error('Exercise recommendations API error:', error);
        return getMockExercises(muscleGroup);
      }
      
      return data?.exercises || [];
    } catch (error) {
      console.error('Error getting exercise recommendations:', error);
      return getMockExercises(muscleGroup);
    }
  }
};

// Mock data functions for fallback
function getMockWorkoutPlan(preferences: any): WorkoutPlan {
  return {
    id: 'mock-workout-1',
    name: `${preferences.goal.replace('_', ' ')} Workout`,
    description: `A ${preferences.duration}-minute ${preferences.experience} level workout focused on ${preferences.goal.replace('_', ' ')}.`,
    duration: preferences.duration,
    difficulty: preferences.experience,
    exercises: getMockExercises('full-body'),
    targetMuscles: preferences.targetMuscles || ['chest', 'back', 'legs']
  };
}

function getMockExercises(muscleGroup: string): Exercise[] {
  const exercises: Exercise[] = [
    {
      id: 'exercise-1',
      name: 'Push-ups',
      description: 'Classic bodyweight exercise targeting chest, shoulders, and triceps.',
      sets: 3,
      reps: '10-15',
      muscleGroups: ['chest', 'shoulders', 'triceps'],
      equipment: ['bodyweight'],
      instructions: [
        'Start in a plank position with hands slightly wider than shoulders',
        'Lower your body until chest nearly touches the floor',
        'Push back up to starting position',
        'Keep your core tight throughout the movement'
      ]
    },
    {
      id: 'exercise-2',
      name: 'Squats',
      description: 'Fundamental lower body exercise targeting quads, glutes, and hamstrings.',
      sets: 3,
      reps: '12-20',
      muscleGroups: ['quads', 'glutes', 'hamstrings'],
      equipment: ['bodyweight'],
      instructions: [
        'Stand with feet shoulder-width apart',
        'Lower your body as if sitting back into a chair',
        'Keep your chest up and weight in your heels',
        'Return to standing position'
      ]
    },
    {
      id: 'exercise-3',
      name: 'Plank',
      description: 'Core stability exercise that engages the entire core.',
      sets: 3,
      reps: '30-60 seconds',
      muscleGroups: ['abs', 'core'],
      equipment: ['bodyweight'],
      instructions: [
        'Start in a push-up position',
        'Hold the position with your body in a straight line',
        'Keep your core tight and breathe normally',
        'Hold for the specified duration'
      ]
    }
  ];

  // Filter exercises based on muscle group if specific
  if (muscleGroup !== 'full-body') {
    return exercises.filter(exercise => 
      exercise.muscleGroups.some(group => 
        group.toLowerCase().includes(muscleGroup.toLowerCase())
      )
    );
  }

  return exercises;
}