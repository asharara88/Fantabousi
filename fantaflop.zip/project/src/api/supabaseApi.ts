import { createClient } from "@supabase/supabase-js";

interface WorkoutSession {
  id: string;
  user_id: string;
  workout_type: string;
  duration: number;
  calories_burned: number;
  timestamp: string;
  notes?: string;
}

interface FitnessSummary {
  totalWorkouts: number;
  totalCaloriesBurned: number;
  totalActiveMinutes: number;
  dailyMetrics: Array<{
    date: string;
    workouts: number;
    caloriesBurned: number;
    activeMinutes: number;
  }>;
}

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL || "",
  import.meta.env.VITE_SUPABASE_ANON_KEY || ""
);

// Workouts API
export const workoutsApi = {
  // Get fitness summary for a user
  getFitnessSummary: async (days: number = 7): Promise<FitnessSummary> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        // Return mock data for demo
        return getMockFitnessSummary();
      }

      const startDate = new Date();
      startDate.setDate(startDate.getDate() - days);

      const { data, error } = await supabase
        .from('workout_sessions')
        .select('*')
        .eq('user_id', user.id)
        .gte('timestamp', startDate.toISOString())
        .order('timestamp', { ascending: false });

      if (error) {
        console.error('Error fetching workout data:', error);
        return getMockFitnessSummary();
      }

      // Process data into summary
      const workouts = data || [];
      const totalWorkouts = workouts.length;
      const totalCaloriesBurned = workouts.reduce((sum, w) => sum + (w.calories_burned || 0), 0);
      const totalActiveMinutes = workouts.reduce((sum, w) => sum + (w.duration || 0), 0);

      // Group by date for daily metrics
      const dailyMetrics = groupWorkoutsByDate(workouts);

      return {
        totalWorkouts,
        totalCaloriesBurned,
        totalActiveMinutes,
        dailyMetrics
      };
    } catch (error) {
      console.error('Error getting fitness summary:', error);
      return getMockFitnessSummary();
    }
  },

  // Log a new workout
  logWorkout: async (workoutData: Omit<WorkoutSession, 'id' | 'user_id'>): Promise<WorkoutSession | null> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }

      const { data, error } = await supabase
        .from('workout_sessions')
        .insert([{
          user_id: user.id,
          ...workoutData,
          timestamp: workoutData.timestamp || new Date().toISOString()
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error logging workout:', error);
      return null;
    }
  },

  // Get workout history
  getWorkoutHistory: async (limit: number = 10): Promise<WorkoutSession[]> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        return getMockWorkouts();
      }

      const { data, error } = await supabase
        .from('workout_sessions')
        .select('*')
        .eq('user_id', user.id)
        .order('timestamp', { ascending: false })
        .limit(limit);

      if (error) {
        console.error('Error fetching workout history:', error);
        return getMockWorkouts();
      }

      return data || [];
    } catch (error) {
      console.error('Error getting workout history:', error);
      return getMockWorkouts();
    }
  }
};

// Helper functions
function groupWorkoutsByDate(workouts: WorkoutSession[]) {
  const grouped = workouts.reduce((acc, workout) => {
    const date = new Date(workout.timestamp).toISOString().split('T')[0];
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(workout);
    return acc;
  }, {} as Record<string, WorkoutSession[]>);

  return Object.entries(grouped).map(([date, workouts]) => ({
    date,
    workouts: workouts.length,
    caloriesBurned: workouts.reduce((sum, w) => sum + (w.calories_burned || 0), 0),
    activeMinutes: workouts.reduce((sum, w) => sum + (w.duration || 0), 0)
  }));
}

function getMockFitnessSummary(): FitnessSummary {
  return {
    totalWorkouts: 4,
    totalCaloriesBurned: 1240,
    totalActiveMinutes: 180,
    dailyMetrics: [
      { date: '2025-01-18', workouts: 1, caloriesBurned: 320, activeMinutes: 45 },
      { date: '2025-01-17', workouts: 1, caloriesBurned: 280, activeMinutes: 40 },
      { date: '2025-01-16', workouts: 1, caloriesBurned: 350, activeMinutes: 50 },
      { date: '2025-01-15', workouts: 1, caloriesBurned: 290, activeMinutes: 45 }
    ]
  };
}

function getMockWorkouts(): WorkoutSession[] {
  return [
    {
      id: '1',
      user_id: 'demo',
      workout_type: 'Strength Training',
      duration: 45,
      calories_burned: 320,
      timestamp: new Date().toISOString(),
      notes: 'Upper body workout'
    },
    {
      id: '2',
      user_id: 'demo',
      workout_type: 'Cardio',
      duration: 30,
      calories_burned: 280,
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      notes: 'HIIT session'
    }
  ];
}