import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const httpsSupabaseUrl = supabaseUrl.replace(/^http:/, 'https:');
const supabase = createClient(httpsSupabaseUrl, supabaseAnonKey);

export interface Voice {
  voice_id: string;
  name: string;
  preview_url?: string;
  category: string;
}

export interface VoiceSettings {
  stability: number;
  similarity_boost: number;
  style?: number;
  use_speaker_boost?: boolean;
}

export interface TextToSpeechRequest {
  text: string;
  voice_id: string;
  voice_settings?: VoiceSettings;
}

export const elevenlabsApi = {
  // Get available voices
  getVoices: async (): Promise<Voice[]> => {
    try {
      const { data, error } = await supabase.functions.invoke('elevenlabs-proxy/voices');
      
      if (error) {
        console.error('ElevenLabs voices API error:', error);
        return getMockVoices();
      }
      
      return data?.voices || getMockVoices();
    } catch (error) {
      console.error('Error getting voices:', error);
      return getMockVoices();
    }
  },

  // Convert text to speech
  textToSpeech: async (request: TextToSpeechRequest): Promise<ArrayBuffer | null> => {
    try {
      const { data, error } = await supabase.functions.invoke('elevenlabs-proxy/text-to-speech', {
        body: request
      });
      
      if (error) {
        console.error('ElevenLabs TTS API error:', error);
        return null;
      }
      
      return data;
    } catch (error) {
      console.error('Error converting text to speech:', error);
      return null;
    }
  },

  // Get user's subscription info
  getUserInfo: async (): Promise<any> => {
    try {
      const { data, error } = await supabase.functions.invoke('elevenlabs-proxy/user');
      
      if (error) {
        console.error('ElevenLabs user info API error:', error);
        return null;
      }
      
      return data;
    } catch (error) {
      console.error('Error getting user info:', error);
      return null;
    }
  },

  // Check if ElevenLabs is configured
  isConfigured: async (): Promise<boolean> => {
    try {
      // Check environment variables first
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (!supabaseUrl) {
        console.warn('Supabase URL not configured');
        return false;
      }

      const { data, error } = await supabase.functions.invoke('elevenlabs-proxy/user');
      
      if (error) {
        console.warn('ElevenLabs configuration check failed:', error);
        return false;
      }
      
      return !!data;
    } catch (error) {
      console.error('Error checking ElevenLabs configuration:', error);
      return false;
    }
  },

  // Get voice settings for a specific voice
  getVoiceSettings: async (voiceId: string): Promise<VoiceSettings | null> => {
    try {
      const { data, error } = await supabase.functions.invoke('elevenlabs-proxy/voice-settings', {
        body: { voice_id: voiceId }
      });
      
      if (error) {
        console.error('ElevenLabs voice settings API error:', error);
        return getDefaultVoiceSettings();
      }
      
      return data || getDefaultVoiceSettings();
    } catch (error) {
      console.error('Error getting voice settings:', error);
      return getDefaultVoiceSettings();
    }
  }
};

// Mock data functions for fallback
function getMockVoices(): Voice[] {
  return [
    {
      voice_id: 'mock-voice-1',
      name: 'Sarah',
      category: 'Generated',
    },
    {
      voice_id: 'mock-voice-2',
      name: 'James',
      category: 'Generated',
    },
    {
      voice_id: 'mock-voice-3',
      name: 'Emily',
      category: 'Cloned',
    }
  ];
}

function getDefaultVoiceSettings(): VoiceSettings {
  return {
    stability: 0.5,
    similarity_boost: 0.8,
    style: 0.0,
    use_speaker_boost: true
  };
}