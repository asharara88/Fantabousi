import { createClient } from '@supabase/supabase-js';
import { Supplement, SupplementStack, RecommendationResponse } from '../types/supplement';

// Initialize Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const httpsSupabaseUrl = supabaseUrl.replace(/^http:/, 'https:');
const supabase = createClient(httpsSupabaseUrl, supabaseAnonKey);

export const supplementApi = {
  // Get all supplements
  getAllSupplements: async (): Promise<Supplement[]> => {
    try {
      const { data, error } = await supabase
        .from('supplements')
        .select('*')
        .eq('is_available', true)
        .order('name');
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching supplements:', error);
      return [];
    }
  },

  // Get supplement by ID
  getSupplementById: async (id: string): Promise<Supplement | null> => {
    try {
      const { data, error } = await supabase
        .from('supplements')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching supplement:', error);
      return null;
    }
  },

  // Search supplements
  searchSupplements: async (query: string): Promise<Supplement[]> => {
    try {
      const { data, error } = await supabase
        .from('supplements')
        .select('*')
        .eq('is_available', true)
        .or(`name.ilike.%${query}%,description.ilike.%${query}%,category.ilike.%${query}%`)
        .order('name');
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error searching supplements:', error);
      return [];
    }
  },

  // Get supplements by category
  getSupplementsByCategory: async (category: string): Promise<Supplement[]> => {
    try {
      const { data, error } = await supabase
        .from('supplements')
        .select('*')
        .eq('category', category)
        .eq('is_available', true)
        .order('name');
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching supplements by category:', error);
      return [];
    }
  },

  // Get supplements by tier
  getSupplementsByTier: async (tier: string): Promise<Supplement[]> => {
    try {
      const { data, error } = await supabase
        .from('supplements')
        .select('*')
        .eq('tier', tier)
        .eq('is_available', true)
        .order('name');
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching supplements by tier:', error);
      return [];
    }
  },

  // Get featured supplements
  getFeaturedSupplements: async (): Promise<Supplement[]> => {
    try {
      const { data, error } = await supabase
        .from('supplements')
        .select('*')
        .eq('is_featured', true)
        .eq('is_available', true)
        .order('name')
        .limit(8);
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching featured supplements:', error);
      return [];
    }
  },

  // Get bestseller supplements
  getBestsellerSupplements: async (): Promise<Supplement[]> => {
    try {
      const { data, error } = await supabase
        .from('supplements')
        .select('*')
        .eq('is_bestseller', true)
        .eq('is_available', true)
        .order('name')
        .limit(8);
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching bestseller supplements:', error);
      return [];
    }
  },

  // Get personalized recommendations
  getPersonalizedRecommendations: async (userId?: string): Promise<RecommendationResponse> => {
    try {
      // Get current user if not provided
      if (!userId) {
        const { data: { user } } = await supabase.auth.getUser();
        userId = user?.id;
      }

      if (!userId) {
        throw new Error('User not authenticated');
      }

      const { data, error } = await supabase.functions.invoke('recommendations', {
        body: { userId }
      });
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching recommendations:', error);
      // Return fallback data
      return {
        supplements: [],
        stacks: [],
        personalized_message: 'Unable to load personalized recommendations at this time.'
      };
    }
  },

  // Get supplement stacks
  getSupplementStacks: async (): Promise<SupplementStack[]> => {
    try {
      const { data, error } = await supabase
        .from('supplement_stacks')
        .select('*')
        .order('category');
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching supplement stacks:', error);
      return [];
    }
  },

  // Get user's custom stacks
  getUserStacks: async (userId?: string): Promise<SupplementStack[]> => {
    try {
      // Get current user if not provided
      if (!userId) {
        const { data: { user } } = await supabase.auth.getUser();
        userId = user?.id;
      }

      if (!userId) {
        throw new Error('User not authenticated');
      }

      const { data, error } = await supabase
        .from('supplement_stacks')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching user stacks:', error);
      return [];
    }
  },

  // Create custom supplement stack
  createSupplementStack: async (stackData: Partial<SupplementStack>): Promise<SupplementStack | null> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }

      const { data, error } = await supabase
        .from('supplement_stacks')
        .insert([{
          ...stackData,
          user_id: user.id,
          created_at: new Date().toISOString()
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating supplement stack:', error);
      return null;
    }
  },

  // Add supplement to cart
  addToCart: async (supplementId: string, quantity: number = 1): Promise<boolean> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Check if item already in cart
      const { data: existingItem } = await supabase
        .from('cart_items')
        .select('*')
        .eq('user_id', user.id)
        .eq('supplement_id', supplementId)
        .single();

      if (existingItem) {
        // Update quantity
        const { error } = await supabase
          .from('cart_items')
          .update({ quantity: existingItem.quantity + quantity })
          .eq('id', existingItem.id);
        
        if (error) throw error;
      } else {
        // Add new item
        const { error } = await supabase
          .from('cart_items')
          .insert([{
            user_id: user.id,
            supplement_id: supplementId,
            quantity
          }]);
        
        if (error) throw error;
      }
      
      return true;
    } catch (error) {
      console.error('Error adding to cart:', error);
      return false;
    }
  },

  // Get cart items
  getCartItems: async (): Promise<any[]> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }

      const { data, error } = await supabase
        .from('cart_items')
        .select(`
          *,
          supplement:supplements(*)
        `)
        .eq('user_id', user.id);
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching cart items:', error);
      return [];
    }
  },

  // Remove from cart
  removeFromCart: async (cartItemId: string): Promise<boolean> => {
    try {
      const { error } = await supabase
        .from('cart_items')
        .delete()
        .eq('id', cartItemId);
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error removing from cart:', error);
      return false;
    }
  },

  // Update cart item quantity
  updateCartItemQuantity: async (cartItemId: string, quantity: number): Promise<boolean> => {
    try {
      const { error } = await supabase
        .from('cart_items')
        .update({ quantity })
        .eq('id', cartItemId);
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating cart item:', error);
      return false;
    }
  }
};