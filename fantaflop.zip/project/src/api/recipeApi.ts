import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const httpsSupabaseUrl = supabaseUrl.replace(/^http:/, 'https:');
const supabase = createClient(httpsSupabaseUrl, supabaseAnonKey);

export interface Recipe {
  id: number;
  title: string;
  image: string;
  readyInMinutes: number;
  servings: number;
  sourceUrl?: string;
  summary: string;
  healthScore: number;
  diets: string[];
  nutrition?: {
    calories: number;
    protein: number;
    fat: number;
    carbs: number;
  };
}

export interface RecipeSearchParams {
  diet?: string;
  intolerances?: string;
  includeIngredients?: string;
  excludeIngredients?: string;
  type?: string;
  maxReadyTime?: number;
  minCalories?: number;
  maxCalories?: number;
  minProtein?: number;
  maxProtein?: number;
  number?: number;
}

export interface RecipeSearchResponse {
  recipes: Recipe[];
  total: number;
}

// API functions
export const recipeApi = {
  // Search for recipes based on user preferences
  searchRecipes: async (params: RecipeSearchParams): Promise<RecipeSearchResponse> => {
    try {
      // Validate environment variables
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (!supabaseUrl) {
        console.warn('Supabase URL not configured, using mock data');
        return {
          recipes: getMockRecipeData(),
          total: getMockRecipeData().length
        };
      }

      const { data, error } = await supabase.functions.invoke('get-personalized-recipes', {
        body: params
      });
      
      if (error) {
        console.error('Recipe API error:', error);
        throw new Error(error.message);
      }
      
      return data;
    } catch (error) {
      console.error('Error searching recipes:', error);
      
      // Fallback to mock data for demo purposes
      return {
        recipes: getMockRecipeData(),
        total: getMockRecipeData().length
      };
    }
  },
  
  // Get recipe details by ID
  getRecipeById: async (recipeId: number): Promise<Recipe | null> => {
    try {
      // Check if we have proper environment setup
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (!supabaseUrl) {
        console.warn('Supabase URL not configured, using mock data');
        const mockRecipes = getMockRecipeData();
        return mockRecipes.find(r => r.id === recipeId) || null;
      }

      const { data, error } = await supabase.functions.invoke('get-personalized-recipes', {
        body: { ids: [recipeId] }
      });
      
      if (error) {
        console.error('Recipe detail API error:', error);
        throw new Error(error.message);
      }
      
      return data.recipes[0] || null;
    } catch (error) {
      console.error('Error getting recipe details:', error);
      
      // Fallback to mock data
      const mockRecipes = getMockRecipeData();
      return mockRecipes.find(r => r.id === recipeId) || null;
    }
  },

  // Get random recipes
  getRandomRecipes: async (number: number = 6): Promise<Recipe[]> => {
    try {
      const response = await this.searchRecipes({ number });
      return response.recipes;
    } catch (error) {
      console.error('Error getting random recipes:', error);
      return getMockRecipeData().slice(0, number);
    }
  },

  // Search recipes by ingredients
  searchByIngredients: async (ingredients: string[]): Promise<Recipe[]> => {
    try {
      const response = await this.searchRecipes({
        includeIngredients: ingredients.join(','),
        number: 12
      });
      return response.recipes;
    } catch (error) {
      console.error('Error searching recipes by ingredients:', error);
      return getMockRecipeData();
    }
  }
};

// Mock data for fallback
function getMockRecipeData(): Recipe[] {
  return [
    {
      id: 1,
      title: "Mediterranean Quinoa Bowl",
      image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400",
      readyInMinutes: 25,
      servings: 4,
      summary: "A healthy and nutritious Mediterranean-inspired quinoa bowl packed with fresh vegetables, olives, and feta cheese.",
      healthScore: 85,
      diets: ["vegetarian", "gluten-free"],
      nutrition: {
        calories: 420,
        protein: 14,
        fat: 18,
        carbs: 52
      }
    },
    {
      id: 2,
      title: "Grilled Salmon with Asparagus",
      image: "https://images.pexels.com/photos/725991/pexels-photo-725991.jpeg?auto=compress&cs=tinysrgb&w=400",
      readyInMinutes: 20,
      servings: 2,
      summary: "Perfectly grilled salmon served with tender asparagus spears and a lemon herb seasoning.",
      healthScore: 92,
      diets: ["keto", "paleo"],
      nutrition: {
        calories: 350,
        protein: 32,
        fat: 22,
        carbs: 8
      }
    },
    {
      id: 3,
      title: "Chickpea Buddha Bowl",
      image: "https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=400",
      readyInMinutes: 30,
      servings: 3,
      summary: "A colorful and nutritious buddha bowl featuring roasted chickpeas, quinoa, and fresh vegetables with tahini dressing.",
      healthScore: 88,
      diets: ["vegan", "gluten-free"],
      nutrition: {
        calories: 380,
        protein: 16,
        fat: 14,
        carbs: 48
      }
    },
    {
      id: 4,
      title: "Turkey and Avocado Wrap",
      image: "https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg?auto=compress&cs=tinysrgb&w=400",
      readyInMinutes: 10,
      servings: 1,
      summary: "A quick and healthy wrap filled with lean turkey, fresh avocado, and crisp vegetables.",
      healthScore: 78,
      diets: ["high-protein"],
      nutrition: {
        calories: 320,
        protein: 24,
        fat: 16,
        carbs: 28
      }
    },
    {
      id: 5,
      title: "Greek Yogurt Berry Parfait",
      image: "https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg?auto=compress&cs=tinysrgb&w=400",
      readyInMinutes: 5,
      servings: 1,
      summary: "A delicious and protein-rich parfait layered with Greek yogurt, fresh berries, and granola.",
      healthScore: 82,
      diets: ["vegetarian", "high-protein"],
      nutrition: {
        calories: 280,
        protein: 18,
        fat: 8,
        carbs: 36
      }
    },
    {
      id: 6,
      title: "Roasted Vegetable Pasta",
      image: "https://images.pexels.com/photos/1640775/pexels-photo-1640775.jpeg?auto=compress&cs=tinysrgb&w=400",
      readyInMinutes: 35,
      servings: 4,
      summary: "Whole grain pasta tossed with colorful roasted vegetables and a light herb sauce.",
      healthScore: 75,
      diets: ["vegetarian"],
      nutrition: {
        calories: 450,
        protein: 12,
        fat: 12,
        carbs: 68
      }
    }
  ];
}