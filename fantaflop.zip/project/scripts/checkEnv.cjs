const fs = require('fs');

function parseEnv(file) {
  let data;
  try {
    data = fs.readFileSync(file, 'utf-8');
  } catch (error) {
    console.error(`Failed to read file: ${file}. Error: ${error.message}`);
    process.exit(1);
  }
  const lines = data.split(/\r?\n/);
  const env = {};
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) continue;
    const key = trimmed.substring(0, eqIdx).trim();
    const value = trimmed.substring(eqIdx + 1).trim();
    env[key] = value;
  }
  return env;
}

const exampleFile = '.env.example';
const envFile = '.env';

if (!fs.existsSync(exampleFile)) {
  console.error('Missing .env.example file');
  process.exit(1);
}

const example = parseEnv(exampleFile);
const requiredKeys = Object.keys(example);

if (!fs.existsSync(envFile)) {
  console.error('Missing .env file. Please copy .env.example to .env and fill out the values.');
  process.exit(1);
}

const actual = parseEnv(envFile);
const missing = [];
const placeholders = [];

for (const key of requiredKeys) {
  const val = actual[key];
  if (val === undefined || !(key in actual)) {
    missing.push(key);
    continue;
  }
  if (val === example[key] || PLACEHOLDER_REGEX.test(val)) {
    placeholders.push(key);
  }
}

if (missing.length || placeholders.length) {
  if (missing.length) {
    console.error('Missing variables: ' + missing.join(', '));
  }
  if (placeholders.length) {
    console.error('Placeholder values detected for: ' + placeholders.join(', '));
  }
  process.exit(1);
}

console.log('Environment variables look good.');

