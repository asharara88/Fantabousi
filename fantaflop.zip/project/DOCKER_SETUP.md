# Docker Setup for Biowell AI

This document explains how to run the Biowell AI application using Docker.

## 🐳 Docker Files Created

- **Dockerfile**: Production build with Nginx
- **Dockerfile.dev**: Development build with hot reload
- **docker-compose.yml**: Multi-service setup
- **nginx.conf**: Nginx configuration for SPA routing
- **.dockerignore**: Optimized Docker build context

## 🚀 Quick Start

### Production Build (Recommended)

```bash
# Build the production image
npm run docker:build

# Run the production container
npm run docker:run

# Or use Docker directly
docker build -t biowell-ai .
docker run -p 8080:80 biowell-ai
```

Access your app at: **<http://localhost:8080>**

### Development with Hot Reload

```bash
# Start development environment
npm run docker:dev

# Or use Docker Compose directly
docker-compose up biowell-dev
```

Access your app at: **<http://localhost:3000>**

## 📋 Available Scripts

| Script | Description |
|--------|-------------|
| `npm run docker:build` | Build production Docker image |
| `npm run docker:build-dev` | Build development Docker image |
| `npm run docker:run` | Run production container on port 8080 |
| `npm run docker:run-dev` | Run development container with volume mounting |
| `npm run docker:dev` | Start development environment with Docker Compose |
| `npm run docker:prod` | Start production environment with Docker Compose |

## 🔧 Docker Compose Services

### Available Services

- **biowell-dev**: Development server with hot reload
- **biowell-prod**: Production Nginx server
- **postgres**: PostgreSQL database (profile: database)
- **redis**: Redis cache (profile: cache)

### Using Profiles

```bash
# Start with database
docker-compose --profile database up biowell-dev postgres

# Start with cache
docker-compose --profile cache up biowell-dev redis

# Production environment
docker-compose --profile production up biowell-prod
```

## 🌍 Environment Variables

Create a `.env` file with your environment variables:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
VITE_OPENAI_API_KEY=your_openai_api_key
```

## 🏗️ Multi-Stage Build Process

The production Dockerfile uses a multi-stage build:

1. **Builder Stage**: Node.js Alpine image
   - Installs dependencies
   - Builds the application
   - Optimizes bundles

2. **Production Stage**: Nginx Alpine image
   - Copies built assets
   - Serves static files
   - Handles SPA routing

## 📁 Production Features

- ✅ Optimized Nginx configuration
- ✅ SPA routing support
- ✅ Gzip compression
- ✅ Security headers
- ✅ Health check endpoint
- ✅ Static asset caching
- ✅ Small image size (~50MB)

## 🔍 Debugging

### Check container logs

```bash
docker logs <container_id>
```

### Access container shell

```bash
docker exec -it <container_id> /bin/sh
```

### Health check

```bash
curl http://localhost:8080/health
```

## 🎯 Performance Benefits

**Why Docker helps revive your app:**

1. **Consistent Environment**: Same runtime everywhere
2. **Isolated Dependencies**: No conflicts with system packages
3. **Production Optimization**: Nginx serving optimized static files
4. **Easy Deployment**: Single container for any environment
5. **Development Consistency**: Same environment as production

## 🚀 Deployment Ready

The Docker setup is ready for:

- Cloud platforms (AWS, GCP, Azure)
- Container orchestration (Kubernetes, Docker Swarm)
- CI/CD pipelines
- Hosting services (Railway, Render, etc.)

## 🔧 Troubleshooting

### Port Conflicts

If port 8080 is in use:

```bash
docker run -p 9000:80 biowell-ai
```

### Build Errors

Clear Docker cache:

```bash
docker builder prune
docker system prune
```

### Environment Issues

Check environment variables are loaded:

```bash
docker run --env-file .env biowell-ai
```

Your Biowell AI app is now fully dockerized and production-ready! 🎉
