import { afterEach, beforeAll, expect, test, vi } from 'vitest';

process.env.SUPABASE_URL = 'http://localhost';
process.env.SUPABASE_SERVICE_ROLE_KEY = 'test';
process.env.OPENAI_API_KEY = 'test';

let handler: typeof import('./index').handler;

beforeAll(async () => {
  handler = (await import('./index')).handler;
});

// Mock fetch globally
const originalFetch = global.fetch;

afterEach(() => {
  global.fetch = originalFetch;
});

test('handler returns recommendation from OpenAI', async () => {
  const metrics = {
    sleep_hours: 7,
    deep_sleep_minutes: 90,
    daily_steps: 8000,
    calories_burned: 2100,
    bmi: 23,
    activity_goal: 'maintenance'
  };

  global.fetch = vi.fn((input: RequestInfo | URL) => {
    const url = typeof input === 'string' ? input : input.toString();

    if (url.includes('api.openai.com')) {
      return Promise.resolve(
        new Response(
          JSON.stringify({ choices: [{ message: { content: 'do more exercise' } }] }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        )
      );
    }

    return Promise.resolve(
      new Response(JSON.stringify(metrics), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      })
    );
  }) as any;

  const req = new Request('http://localhost', {
    method: 'POST',
    body: JSON.stringify({ userId: '1', userQuestion: 'how to improve health?' })
  });

  const res = await handler(req);
  const body = await res.json();

  expect(body.reply).toBe('do more exercise');
});
