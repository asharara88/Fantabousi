var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stripe_webhook_exports = {};
__export(stripe_webhook_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(stripe_webhook_exports);
async function handler(event, context) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const body = JSON.parse(event.body);
    switch (body.type) {
      case "checkout.session.completed":
        console.log("Payment completed:", body.data.object);
        break;
      case "customer.subscription.created":
        console.log("Subscription created:", body.data.object);
        break;
      case "customer.subscription.updated":
        console.log("Subscription updated:", body.data.object);
        break;
      case "customer.subscription.deleted":
        console.log("Subscription cancelled:", body.data.object);
        break;
      default:
        console.log("Unhandled event type:", body.type);
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ received: true })
    };
  } catch (error) {
    console.error("Webhook error:", error);
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Invalid payload" })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
